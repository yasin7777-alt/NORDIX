import { useEffect } from 'react';
import { HashRouter, Navigate, Route, Routes, useLocation } from 'react-router-dom';
import { Header } from './components/Header';
import { ProgressProvider } from './lib/ProgressContext';
import { Lesson } from './pages/Lesson';
import { Lab } from './pages/Lab';
import { ProgressPage } from './pages/ProgressPage';
import { Certificate } from './pages/Certificate';
const FIRST = '/learn/course-1/c1-l1';
function ScrollToTop() { const { pathname } = useLocation(); useEffect(() => { window.scrollTo({ top: 0, behavior: 'instant' }); document.title = pathname === '/lab' ? 'NORDIX LAB' : 'NORDIX Academy'; }, [pathname]); return null; }
export default function App() { return <ProgressProvider><HashRouter><ScrollToTop/><div className="flex min-h-screen flex-col bg-ink"><Header/><div className="flex-1"><Routes><Route path="/" element={<Navigate to={FIRST} replace/>}/><Route path="/education" element={<Navigate to={FIRST} replace/>}/><Route path="/learn/:courseId/:lessonId" element={<Lesson/>}/><Route path="/lab" element={<Lab/>}/><Route path="/progress" element={<ProgressPage/>}/><Route path="/certificate/:courseId" element={<Certificate/>}/><Route path="*" element={<Navigate to={FIRST} replace/>}/></Routes></div><footer className="border-t border-line px-6 py-8 text-center text-sm text-fog">© 2026 NORDIX · Учебные симуляции не заменяют профессиональный допуск.</footer></div></HashRouter></ProgressProvider>; }
