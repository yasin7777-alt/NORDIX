import type { CycleNodeId } from '../lib/types';

interface CycleDiagramProps {
  onNodeClick?: (id: CycleNodeId) => void;
  highlight?: CycleNodeId | null;
  wrongFlash?: CycleNodeId | null;
  animate?: boolean;
  compact?: boolean;
}

const NODES: { id: CycleNodeId; label: string; sub: string; x: number; y: number }[] = [
  { id: 'compressor', label: 'Компрессор', sub: 'сжатие пара', x: 90, y: 190 },
  { id: 'condenser', label: 'Конденсатор', sub: 'отдача тепла', x: 320, y: 60 },
  { id: 'expansion', label: 'ТРВ / дроссель', sub: 'падение давления', x: 550, y: 190 },
  { id: 'evaporator', label: 'Испаритель', sub: 'кипение, забор тепла', x: 320, y: 320 },
];

export function CycleDiagram({ onNodeClick, highlight = null, wrongFlash = null, animate = true, compact = false }: CycleDiagramProps) {
  const hotPath = 'M 90 150 C 90 90 180 60 280 60 M 360 60 C 470 60 550 100 550 150';
  const coldPath = 'M 550 230 C 550 290 470 320 360 320 M 280 320 C 180 320 90 290 90 230';

  return (
    <svg
      viewBox="0 0 640 380"
      className={`w-full ${compact ? 'max-h-64' : 'max-h-[420px]'}`}
      role="img"
      aria-label="Схема холодильного цикла"
    >
      <path d={hotPath} fill="none" stroke="#e0a13c" strokeWidth="6" strokeLinecap="round" opacity="0.85" className={animate ? 'flow-line-slow' : ''} />
      <path d={coldPath} fill="none" stroke="#3d75d8" strokeWidth="6" strokeLinecap="round" opacity="0.9" className={animate ? 'flow-line' : ''} />

      <text x="320" y="26" textAnchor="middle" fill="#8b939e" fontSize="13" fontFamily="Manrope, sans-serif">
        сторона высокого давления (ВС)
      </text>
      <text x="320" y="368" textAnchor="middle" fill="#8b939e" fontSize="13" fontFamily="Manrope, sans-serif">
        сторона низкого давления (НС)
      </text>

      {NODES.map((node) => {
        const active = highlight === node.id;
        const wrong = wrongFlash === node.id;
        const clickable = Boolean(onNodeClick);
        return (
          <g
            key={node.id}
            onClick={() => onNodeClick?.(node.id)}
            className={clickable ? 'cursor-pointer' : ''}
            role={clickable ? 'button' : undefined}
            aria-label={clickable ? `Узел: ${node.label}` : undefined}
          >
            <rect
              x={node.x - 78}
              y={node.y - 34}
              width="156"
              height="68"
              rx="14"
              fill={wrong ? '#3a1d1d' : active ? '#12233f' : '#171b21'}
              stroke={wrong ? '#e05656' : active ? '#3d75d8' : '#2e343d'}
              strokeWidth={active || wrong ? 3 : 1.5}
              className="transition-all duration-200"
            />
            <text
              x={node.x}
              y={node.y - 4}
              textAnchor="middle"
              fill="#f2f4f7"
              fontSize="16"
              fontWeight="700"
              fontFamily="Manrope, sans-serif"
            >
              {node.label}
            </text>
            <text x={node.x} y={node.y + 18} textAnchor="middle" fill="#8b939e" fontSize="12" fontFamily="Manrope, sans-serif">
              {node.sub}
            </text>
          </g>
        );
      })}
    </svg>
  );
}
