import { Info } from 'lucide-react';
import type { Lesson } from '../../lib/types';

export function VideoStage({ lesson }: { lesson: Lesson }) {
  return (
    <div className="space-y-5">
      <h3 className="font-display text-xl font-bold text-paper sm:text-2xl">{lesson.video.caption}</h3>
      <div className="overflow-hidden rounded-2xl border border-line bg-black">
        <video
          src={import.meta.env.BASE_URL + lesson.video.src}
          controls
          preload="metadata"
          playsInline
          className="aspect-video w-full object-cover"
        >
          Ваш браузер не поддерживает воспроизведение видео.
        </video>
      </div>
      <p className="flex items-start gap-3 rounded-xl border border-line bg-steel p-4 text-sm leading-relaxed text-fog">
        <Info className="mt-0.5 h-4 w-4 shrink-0 text-accent-soft" />
        {lesson.video.note}
      </p>
      <p className="text-sm text-fog">
        Смотрите видео с паузами: проговаривайте вслух, что происходит в кадре, своими словами — так материал
        закрепляется быстрее.
      </p>
    </div>
  );
}
