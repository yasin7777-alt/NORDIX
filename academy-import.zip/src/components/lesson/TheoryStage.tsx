import { KeyRound, Lightbulb } from 'lucide-react';
import type { Lesson } from '../../lib/types';

export function TheoryStage({ lesson }: { lesson: Lesson }) {
  return (
    <div className="space-y-8">
      <p className="text-lg leading-relaxed text-silver">{lesson.theory.intro}</p>

      {lesson.theory.sections.map((section) => (
        <section key={section.heading}>
          <h3 className="font-display text-xl font-bold text-paper sm:text-2xl">{section.heading}</h3>
          <p className="mt-3 leading-relaxed text-silver">{section.text}</p>
        </section>
      ))}

      <figure className="overflow-hidden rounded-2xl border border-line bg-steel">
        <img src={import.meta.env.BASE_URL + lesson.illustration.src} alt={lesson.illustration.alt} className="h-56 w-full object-cover sm:h-72" loading="lazy" />
        <figcaption className="px-5 py-3 text-sm text-fog">{lesson.illustration.caption}</figcaption>
      </figure>

      <section>
        <h3 className="flex items-center gap-2 font-display text-xl font-bold text-paper">
          <KeyRound className="h-5 w-5 text-accent-soft" />
          Словарь урока
        </h3>
        <dl className="mt-4 grid gap-3 sm:grid-cols-2">
          {lesson.terms.map((entry) => (
            <div
              key={entry.term}
              className="rounded-xl border border-line bg-steel p-4 transition-colors duration-200 hover:border-accent/60"
            >
              <dt className="font-bold text-paper">{entry.term}</dt>
              <dd className="mt-1 text-sm leading-relaxed text-fog">{entry.def}</dd>
            </div>
          ))}
        </dl>
      </section>

      <section className="rounded-2xl border border-accent/40 bg-accent/10 p-5">
        <h3 className="flex items-center gap-2 font-display text-lg font-bold text-paper">
          <Lightbulb className="h-5 w-5 text-accent-soft" />
          Ключевые мысли
        </h3>
        <ul className="mt-3 space-y-2">
          {lesson.theory.keyPoints.map((point) => (
            <li key={point} className="flex gap-3 text-sm leading-relaxed text-silver">
              <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-accent" />
              {point}
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
