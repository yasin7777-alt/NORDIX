import { useState } from 'react';
import { ShieldCheck, ShieldAlert } from 'lucide-react';

const RULES = [
  'Любые работы с электричеством начинаются только после снятия напряжения, проверки его отсутствия и вывешивания запрещающего плаката.',
  'Хладагент — не «воздух»: баллоны и контур нельзя греть, сверлить и стравливать в помещение. Утечка в замкнутом объёме вытесняет кислород.',
  'Пайка и механические работы ведутся только в СИЗ: защитные очки, перчатки, спецодежда. Открытый огонь — под контролем.',
  'Оборудование под давлением не вскрывается до полного сброса давления и восстановления атмосферы в контуре.',
];

const SAFETY_QUESTIONS = [
  {
    q: 'Первое действие перед работой с электрооборудованием установки:',
    options: ['Надеть перчатки и работать под напряжением', 'Снять напряжение, проверить отсутствие, вывесить плакат', 'Попросить коллегу подстраховать', 'Обесточить только освещение'],
    correct: 1,
  },
  {
    q: 'Почему нельзя стравливать хладагент в помещение?',
    options: ['Он красит стены', 'Вытесняет кислород и создаёт риск удушья и обморожений', 'Он взрывается от света', 'Это запрещено только летом'],
    correct: 1,
  },
  {
    q: 'Минимальный комплект СИЗ для пайки трубопроводов:',
    options: ['Кепка и наушники', 'Очки, перчатки, спецодежда', 'Только перчатки', 'Ничего не нужно'],
    correct: 1,
  },
  {
    q: 'Когда можно вскрыть контур холодильной машины?',
    options: ['Когда компрессор остановлен', 'После полного сброса давления', 'Когда манометр показывает высокое давление', 'В любой момент'],
    correct: 1,
  },
];

export function SafetyGate({ onPassed }: { onPassed: () => void }) {
  const [answers, setAnswers] = useState<(number | null)[]>(SAFETY_QUESTIONS.map(() => null));
  const [feedback, setFeedback] = useState<'none' | 'fail' | 'pass'>('none');

  const allAnswered = answers.every((a) => a !== null);
  const allCorrect = SAFETY_QUESTIONS.every((question, i) => answers[i] === question.correct);

  const check = () => {
    if (allCorrect) {
      setFeedback('pass');
      onPassed();
    } else {
      setFeedback('fail');
    }
  };

  return (
    <div className="rounded-2xl border border-warn/40 bg-warn/5 p-6">
      <h3 className="flex items-center gap-3 font-display text-xl font-bold text-paper">
        <ShieldAlert className="h-6 w-6 text-warn" />
        Инструктаж по технике безопасности
      </h3>
      <p className="mt-2 text-sm leading-relaxed text-silver">
        Все задания выполняются только виртуально. Этот инструктаж не является допуском к реальной работе: электричество, хладагенты и оборудование под давлением обслуживают квалифицированные специалисты. Практические задания NORDIX открываются только после обязательного инструктажа. Прочитайте четыре правила и
        подтвердите понимание мини-тестом.
      </p>
      <ul className="mt-4 space-y-2">
        {RULES.map((rule, i) => (
          <li key={rule} className="flex gap-3 rounded-xl border border-line bg-steel p-3 text-sm leading-relaxed text-silver">
            <span className="font-display font-bold text-warn">{i + 1}</span>
            {rule}
          </li>
        ))}
      </ul>

      <div className="mt-6 space-y-5">
        {SAFETY_QUESTIONS.map((question, qi) => (
          <fieldset key={question.q}>
            <legend className="text-sm font-bold text-paper">{qi + 1}. {question.q}</legend>
            <div className="mt-2 grid gap-2">
              {question.options.map((option, oi) => (
                <label
                  key={option}
                  className={`flex cursor-pointer items-center gap-3 rounded-lg border px-3 py-2 text-sm transition-colors duration-150 ${
                    answers[qi] === oi ? 'border-accent bg-accent/15 text-paper' : 'border-line bg-coal text-silver hover:border-accent/50'
                  }`}
                >
                  <input
                    type="radio"
                    name={`safety-${qi}`}
                    className="accent-[#3d75d8]"
                    checked={answers[qi] === oi}
                    onChange={() => {
                      setAnswers((prev) => prev.map((a, i) => (i === qi ? oi : a)));
                      setFeedback('none');
                    }}
                  />
                  {option}
                </label>
              ))}
            </div>
          </fieldset>
        ))}
      </div>

      {feedback === 'fail' && (
        <p className="mt-4 rounded-lg border border-bad/50 bg-bad/10 px-4 py-3 text-sm text-bad">
          Есть ошибки. Перечитайте правила и исправьте ответы — практика откроется после 4 из 4.
        </p>
      )}
      {feedback === 'pass' && (
        <p className="mt-4 flex items-center gap-2 rounded-lg border border-ok/50 bg-ok/10 px-4 py-3 text-sm text-ok">
          <ShieldCheck className="h-4 w-4" /> Инструктаж пройден. Практика открыта.
        </p>
      )}

      <button
        type="button"
        onClick={check}
        disabled={!allAnswered}
        className="mt-5 rounded-full bg-warn px-6 py-2.5 text-sm font-bold text-black transition-all duration-200 hover:scale-105 hover:bg-warn/90 disabled:cursor-not-allowed disabled:opacity-40"
      >
        Подтвердить понимание
      </button>
    </div>
  );
}
