import { Link } from 'react-router-dom';
import { CheckCircle2, Circle } from 'lucide-react';
import type { CourseMeta, Lesson } from '../../lib/types';
import { Logo } from '../Logo';

interface LessonSidebarProps {
  course: CourseMeta;
  lessons: Lesson[];
  currentLessonId: string;
  completedIds: string[];
  percent: number;
}

export function LessonSidebar({ course, lessons, currentLessonId, completedIds, percent }: LessonSidebarProps) {
  return (
    <aside className="rounded-2xl border border-line bg-coal p-5 lg:sticky lg:top-20 lg:max-h-[calc(100vh-6rem)] lg:overflow-y-auto">
      <Link to="/" aria-label="NORDIX — на главную">
        <Logo size="sm" />
      </Link>
      <div className="mt-4 border-t border-line pt-4">
        <p className="text-xs font-bold uppercase tracking-widest text-fog">Курс {course.num}</p>
        <h2 className="mt-1 font-display text-lg font-bold leading-snug text-paper">{course.title}</h2>
      </div>

      <div className="mt-4">
        <div className="flex items-center justify-between text-xs font-bold text-silver">
          <span>Прогресс курса</span>
          <span className="text-accent-soft">{percent}%</span>
        </div>
        <div className="mt-2 h-2 overflow-hidden rounded-full bg-steel">
          <div className="h-full rounded-full bg-accent transition-all duration-500" style={{ width: `${percent}%` }} />
        </div>
      </div>

      <nav className="mt-5" aria-label="Уроки курса">
        <ul className="space-y-1">
          {lessons.map((lesson) => {
            const done = completedIds.includes(lesson.id);
            const active = lesson.id === currentLessonId;
            return (
              <li key={lesson.id}>
                <Link
                  to={`/learn/${course.id}/${lesson.id}`}
                  className={`flex items-start gap-3 rounded-lg px-3 py-2 text-sm transition-colors duration-150 ${
                    active ? 'bg-accent/15 font-bold text-paper' : 'text-silver hover:bg-steel hover:text-paper'
                  }`}
                >
                  {done ? (
                    <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-ok" aria-label="Урок пройден" />
                  ) : (
                    <Circle className="mt-0.5 h-4 w-4 shrink-0 text-fog/50" aria-label="Урок не пройден" />
                  )}
                  <span>
                    <span className="text-xs text-fog">Урок {lesson.num}.</span> {lesson.title}
                  </span>
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
    </aside>
  );
}
