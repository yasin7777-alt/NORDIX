import { BookOpen, ClipboardCheck, FlaskConical, Trophy, Video } from 'lucide-react';
import type { StageId } from '../../lib/types';

const STAGES: { id: StageId; label: string; icon: typeof BookOpen }[] = [
  { id: 'theory', label: 'Теория', icon: BookOpen },
  { id: 'video', label: 'Видео', icon: Video },
  { id: 'practice', label: 'Практика', icon: FlaskConical },
  { id: 'quiz', label: 'Викторина', icon: ClipboardCheck },
  { id: 'result', label: 'Результат', icon: Trophy },
];

interface StageStepperProps {
  current: StageId;
  quizDone: boolean;
  onSelect: (stage: StageId) => void;
}

export function StageStepper({ current, quizDone, onSelect }: StageStepperProps) {
  return (
    <div className="flex flex-wrap gap-2" role="tablist" aria-label="Этапы урока">
      {STAGES.map((stage, index) => {
        const locked = stage.id === 'result' && !quizDone;
        const active = current === stage.id;
        const Icon = stage.icon;
        return (
          <button
            key={stage.id}
            type="button"
            role="tab"
            aria-selected={active}
            disabled={locked}
            onClick={() => onSelect(stage.id)}
            className={`inline-flex items-center gap-2 rounded-full border px-4 py-2 text-sm font-bold transition-all duration-200 ${
              active
                ? 'border-accent bg-accent text-white shadow-lg shadow-accent/25'
                : locked
                  ? 'cursor-not-allowed border-line/60 bg-steel/40 text-fog/50'
                  : 'border-line bg-steel text-silver hover:border-accent hover:text-paper hover:scale-[1.03]'
            }`}
          >
            <span className="font-display text-[10px] text-current opacity-70">{index + 1}</span>
            <Icon className="h-4 w-4" />
            {stage.label}
          </button>
        );
      })}
    </div>
  );
}
