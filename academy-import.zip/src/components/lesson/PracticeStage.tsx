import { useMemo, useState } from 'react';
import { ArrowDown, ArrowUp, CheckCircle2, MousePointerClick, RotateCcw } from 'lucide-react';
import type { CycleNodeId, PracticeTask } from '../../lib/types';
import { CycleDiagram } from '../CycleDiagram';
import { SafetyGate } from './SafetyGate';

function shuffled<T>(source: T[]): T[] {
  const arr = [...source];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

interface PracticeStageProps {
  task: PracticeTask;
  safetyPassed: boolean;
  onSafetyPassed: () => void;
}

export function PracticeStage({ task, safetyPassed, onSafetyPassed }: PracticeStageProps) {
  if (!safetyPassed) {
    return <SafetyGate onPassed={onSafetyPassed} />;
  }
  return (
    <div className="space-y-5">
      <h3 className="font-display text-xl font-bold text-paper sm:text-2xl">{task.title}</h3>
      <p className="text-sm leading-relaxed text-fog">{task.prompt}</p>
      {task.kind === 'match' && <MatchTask task={task} />}
      {task.kind === 'order' && <OrderTask task={task} />}
      {task.kind === 'choice' && <ChoiceTask task={task} />}
      {task.kind === 'cycle-click' && <CycleClickTask task={task} />}
    </div>
  );
}

function SolvedBanner({ onReset }: { onReset: () => void }) {
  return (
    <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-ok/50 bg-ok/10 px-4 py-3">
      <p className="flex items-center gap-2 text-sm font-bold text-ok">
        <CheckCircle2 className="h-5 w-5" /> Задание выполнено верно. Отличная работа!
      </p>
      <button
        type="button"
        onClick={onReset}
        className="inline-flex items-center gap-2 rounded-full border border-line px-4 py-1.5 text-xs font-bold text-silver transition-colors hover:border-accent hover:text-paper"
      >
        <RotateCcw className="h-3.5 w-3.5" /> Пройти ещё раз
      </button>
    </div>
  );
}

function MatchTask({ task }: { task: Extract<PracticeTask, { kind: 'match' }> }) {
  const rights = useMemo(() => shuffled(task.pairs.map((p) => p.right)), [task]);
  const [selectedLeft, setSelectedLeft] = useState<number | null>(null);
  const [assign, setAssign] = useState<(number | null)[]>(task.pairs.map(() => null));
  const [results, setResults] = useState<boolean[] | null>(null);

  const solved = results !== null && results.every(Boolean);

  const pickRight = (rightIndex: number) => {
    if (selectedLeft === null) return;
    setAssign((prev) => prev.map((a, i) => (a === rightIndex ? null : i === selectedLeft ? rightIndex : a)));
    setSelectedLeft(null);
    setResults(null);
  };

  const check = () => {
    setResults(task.pairs.map((pair, i) => assign[i] !== null && rights[assign[i] as number] === pair.right));
  };

  const reset = () => {
    setAssign(task.pairs.map(() => null));
    setResults(null);
    setSelectedLeft(null);
  };

  return (
    <div className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="space-y-2">
          {task.pairs.map((pair, i) => (
            <button
              key={pair.left}
              type="button"
              onClick={() => setSelectedLeft(selectedLeft === i ? null : i)}
              className={`w-full rounded-xl border px-4 py-3 text-left text-sm font-bold transition-all duration-150 ${
                selectedLeft === i
                  ? 'border-accent bg-accent/20 text-paper'
                  : results
                    ? results[i]
                      ? 'border-ok/60 bg-ok/10 text-paper'
                      : 'border-bad/60 bg-bad/10 text-paper'
                    : 'border-line bg-steel text-silver hover:border-accent/60 hover:text-paper'
              }`}
            >
              {pair.left}
              {assign[i] !== null && (
                <span className="mt-1 block text-xs font-medium text-fog">→ {rights[assign[i] as number]}</span>
              )}
            </button>
          ))}
        </div>
        <div className="space-y-2">
          {rights.map((right, ri) => {
            const taken = assign.includes(ri);
            return (
              <button
                key={right}
                type="button"
                onClick={() => pickRight(ri)}
                className={`w-full rounded-xl border px-4 py-3 text-left text-sm transition-all duration-150 ${
                  taken
                    ? 'border-line/50 bg-coal text-fog/60'
                    : 'border-line bg-steel text-silver hover:border-accent/60 hover:text-paper'
                }`}
              >
                {right}
              </button>
            );
          })}
        </div>
      </div>
      <div className="flex flex-wrap gap-3">
        <button
          type="button"
          onClick={check}
          disabled={assign.some((a) => a === null)}
          className="rounded-full bg-accent px-6 py-2.5 text-sm font-bold text-white transition-all duration-200 hover:bg-accent-deep hover:scale-105 disabled:cursor-not-allowed disabled:opacity-40"
        >
          Проверить пары
        </button>
      </div>
      {results && !solved && (
        <p className="rounded-lg border border-bad/50 bg-bad/10 px-4 py-3 text-sm text-bad">
          Не все пары верны: красным отмечены ошибки. Сверьтесь с теорией и исправьте.
        </p>
      )}
      {solved && <SolvedBanner onReset={reset} />}
    </div>
  );
}

function OrderTask({ task }: { task: Extract<PracticeTask, { kind: 'order' }> }) {
  const [items, setItems] = useState<string[]>(() => {
    let arr = shuffled(task.steps);
    while (arr.join('|') === task.steps.join('|')) arr = shuffled(task.steps);
    return arr;
  });
  const [checked, setChecked] = useState(false);
  const solved = checked && items.join('|') === task.steps.join('|');

  const move = (index: number, dir: -1 | 1) => {
    const target = index + dir;
    if (target < 0 || target >= items.length) return;
    setItems((prev) => {
      const next = [...prev];
      [next[index], next[target]] = [next[target], next[index]];
      return next;
    });
    setChecked(false);
  };

  const reset = () => {
    setItems(shuffled(task.steps));
    setChecked(false);
  };

  return (
    <div className="space-y-4">
      <ol className="space-y-2">
        {items.map((item, i) => (
          <li
            key={item}
            className={`flex items-center gap-3 rounded-xl border px-4 py-3 transition-colors duration-150 ${
              checked ? (item === task.steps[i] ? 'border-ok/60 bg-ok/10' : 'border-bad/60 bg-bad/10') : 'border-line bg-steel'
            }`}
          >
            <span className="font-display text-sm font-bold text-accent-soft">{i + 1}</span>
            <span className="flex-1 text-sm text-silver">{item}</span>
            <span className="flex gap-1">
              <button
                type="button"
                onClick={() => move(i, -1)}
                disabled={i === 0}
                aria-label="Переместить выше"
                className="rounded-md border border-line p-1.5 text-silver transition-colors hover:border-accent hover:text-paper disabled:opacity-30"
              >
                <ArrowUp className="h-4 w-4" />
              </button>
              <button
                type="button"
                onClick={() => move(i, 1)}
                disabled={i === items.length - 1}
                aria-label="Переместить ниже"
                className="rounded-md border border-line p-1.5 text-silver transition-colors hover:border-accent hover:text-paper disabled:opacity-30"
              >
                <ArrowDown className="h-4 w-4" />
              </button>
            </span>
          </li>
        ))}
      </ol>
      <button
        type="button"
        onClick={() => setChecked(true)}
        className="rounded-full bg-accent px-6 py-2.5 text-sm font-bold text-white transition-all duration-200 hover:bg-accent-deep hover:scale-105"
      >
        Проверить порядок
      </button>
      {checked && !solved && (
        <p className="rounded-lg border border-bad/50 bg-bad/10 px-4 py-3 text-sm text-bad">
          Порядок пока неверный: красным отмечены шаги не на своих местах.
        </p>
      )}
      {solved && <SolvedBanner onReset={reset} />}
    </div>
  );
}

function ChoiceTask({ task }: { task: Extract<PracticeTask, { kind: 'choice' }> }) {
  const [selected, setSelected] = useState<number | null>(null);
  const [checked, setChecked] = useState(false);
  const solved = checked && selected === task.correct;

  const reset = () => {
    setSelected(null);
    setChecked(false);
  };

  return (
    <div className="space-y-4">
      <div className="grid gap-2">
        {task.options.map((option, i) => (
          <label
            key={option}
            className={`flex cursor-pointer items-center gap-3 rounded-xl border px-4 py-3 text-sm transition-colors duration-150 ${
              checked
                ? i === task.correct
                  ? 'border-ok/60 bg-ok/10 text-paper'
                  : selected === i
                    ? 'border-bad/60 bg-bad/10 text-paper'
                    : 'border-line bg-steel text-fog'
                : selected === i
                  ? 'border-accent bg-accent/15 text-paper'
                  : 'border-line bg-steel text-silver hover:border-accent/50'
            }`}
          >
            <input
              type="radio"
              name="practice-choice"
              className="accent-[#3d75d8]"
              checked={selected === i}
              onChange={() => {
                setSelected(i);
                setChecked(false);
              }}
            />
            {option}
          </label>
        ))}
      </div>
      <button
        type="button"
        onClick={() => setChecked(true)}
        disabled={selected === null}
        className="rounded-full bg-accent px-6 py-2.5 text-sm font-bold text-white transition-all duration-200 hover:bg-accent-deep hover:scale-105 disabled:cursor-not-allowed disabled:opacity-40"
      >
        Проверить ответ
      </button>
      {checked && (
        <p
          className={`rounded-lg border px-4 py-3 text-sm leading-relaxed ${
            solved ? 'border-ok/50 bg-ok/10 text-ok' : 'border-bad/50 bg-bad/10 text-bad'
          }`}
        >
          {task.explanation}
        </p>
      )}
      {solved && <SolvedBanner onReset={reset} />}
    </div>
  );
}

function CycleClickTask({ task }: { task: Extract<PracticeTask, { kind: 'cycle-click' }> }) {
  const [index, setIndex] = useState(0);
  const [highlight, setHighlight] = useState<CycleNodeId | null>(null);
  const [wrongFlash, setWrongFlash] = useState<CycleNodeId | null>(null);
  const done = index >= task.questions.length;

  const handleClick = (id: CycleNodeId) => {
    if (done) return;
    const current = task.questions[index];
    if (id === current.nodeId) {
      setHighlight(id);
      window.setTimeout(() => setHighlight(null), 900);
      setIndex((i) => i + 1);
    } else {
      setWrongFlash(id);
      window.setTimeout(() => setWrongFlash(null), 700);
    }
  };

  const reset = () => {
    setIndex(0);
    setHighlight(null);
    setWrongFlash(null);
  };

  return (
    <div className="space-y-4">
      <div className="rounded-xl border border-line bg-steel p-5">
        <CycleDiagram onNodeClick={handleClick} highlight={highlight} wrongFlash={wrongFlash} />
      </div>
      {!done ? (
        <p className="flex items-center gap-2 rounded-xl border border-accent/40 bg-accent/10 px-4 py-3 text-sm font-bold text-paper">
          <MousePointerClick className="h-4 w-4 text-accent-soft" />
          Вопрос {index + 1} из {task.questions.length}: {task.questions[index].prompt}
        </p>
      ) : (
        <SolvedBanner onReset={reset} />
      )}
    </div>
  );
}
