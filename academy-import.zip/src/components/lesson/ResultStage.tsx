import { ArrowRight, RotateCcw, XCircle, CheckCircle2 } from 'lucide-react';
import type { QuizQuestion } from '../../lib/types';
import type { QuizResult } from '../../lib/quiz';
import { buildRecommendations } from '../../lib/quiz';

interface ResultStageProps {
  questions: QuizQuestion[];
  result: QuizResult;
  lessonTitle: string;
  onRetry: () => void;
  onNext: (() => void) | null;
}

export function ResultStage({ questions, result, lessonTitle, onRetry, onNext }: ResultStageProps) {
  const recommendations = buildRecommendations(questions, result, lessonTitle);

  return (
    <div className="space-y-6">
      <div
        className={`rounded-2xl border p-6 text-center ${
          result.passed ? 'border-ok/50 bg-ok/10' : 'border-warn/50 bg-warn/10'
        }`}
      >
        <p className="font-display text-5xl font-extrabold text-paper">{result.percent}%</p>
        <p className="mt-2 text-sm font-bold text-silver">
          {result.correct} из {result.total} верно · {result.passed ? 'викторина зачтена' : 'ниже проходного балла 70%'}
        </p>
      </div>

      <section className="space-y-3">
        <h3 className="font-display text-lg font-bold text-paper">Разбор ответов</h3>
        {questions.map((question, i) => {
          const ok = result.perQuestion[i];
          return (
            <div
              key={question.q}
              className={`rounded-xl border p-4 ${ok ? 'border-ok/40 bg-ok/5' : 'border-bad/40 bg-bad/5'}`}
            >
              <p className="flex items-start gap-2 text-sm font-bold text-paper">
                {ok ? <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-ok" /> : <XCircle className="mt-0.5 h-4 w-4 shrink-0 text-bad" />}
                {question.q}
              </p>
              {!ok && (
                <p className="mt-2 text-xs text-silver">
                  Верный ответ: <span className="font-bold text-ok">{question.options[question.correct]}</span>
                </p>
              )}
              <p className="mt-2 text-xs leading-relaxed text-fog">{question.explain}</p>
            </div>
          );
        })}
      </section>

      <section className="rounded-2xl border border-accent/40 bg-accent/10 p-5">
        <h3 className="font-display text-lg font-bold text-paper">Результат и рекомендации</h3>
        <ul className="mt-3 space-y-2">
          {recommendations.map((rec) => (
            <li key={rec} className="flex gap-3 text-sm leading-relaxed text-silver">
              <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-accent" />
              {rec}
            </li>
          ))}
        </ul>
      </section>

      <div className="flex flex-wrap gap-3">
        <button
          type="button"
          onClick={onRetry}
          className="inline-flex items-center gap-2 rounded-full border border-line px-6 py-2.5 text-sm font-bold text-silver transition-all duration-200 hover:border-accent hover:text-paper hover:scale-105"
        >
          <RotateCcw className="h-4 w-4" /> Пройти викторину ещё раз
        </button>
        {onNext && (
          <button
            type="button"
            onClick={onNext}
            className="inline-flex items-center gap-2 rounded-full bg-accent px-6 py-2.5 text-sm font-bold text-white transition-all duration-200 hover:bg-accent-deep hover:scale-105"
          >
            Следующий урок <ArrowRight className="h-4 w-4" />
          </button>
        )}
      </div>
    </div>
  );
}
