import { useState } from 'react';
import { Send } from 'lucide-react';
import type { QuizQuestion } from '../../lib/types';

interface QuizStageProps {
  questions: QuizQuestion[];
  onSubmit: (answers: (number | null)[]) => void;
}

export function QuizStage({ questions, onSubmit }: QuizStageProps) {
  const [answers, setAnswers] = useState<(number | null)[]>(questions.map(() => null));
  const allAnswered = answers.every((a) => a !== null);

  return (
    <div className="space-y-6">
      <p className="text-sm leading-relaxed text-fog">
        Ответьте на все вопросы и отправьте викторину. Разбор каждого ответа и рекомендации вы получите на этапе
        «Результат». Проходной балл — 70%.
      </p>
      {questions.map((question, qi) => (
        <fieldset key={question.q} className="rounded-2xl border border-line bg-steel p-5">
          <legend className="font-bold text-paper">
            {qi + 1}. {question.q}
          </legend>
          <div className="mt-3 grid gap-2">
            {question.options.map((option, oi) => (
              <label
                key={option}
                className={`flex cursor-pointer items-center gap-3 rounded-lg border px-4 py-2.5 text-sm transition-colors duration-150 ${
                  answers[qi] === oi
                    ? 'border-accent bg-accent/15 text-paper'
                    : 'border-line bg-coal text-silver hover:border-accent/50'
                }`}
              >
                <input
                  type="radio"
                  name={`quiz-${qi}`}
                  className="accent-[#3d75d8]"
                  checked={answers[qi] === oi}
                  onChange={() => setAnswers((prev) => prev.map((a, i) => (i === qi ? oi : a)))}
                />
                {option}
              </label>
            ))}
          </div>
        </fieldset>
      ))}
      <button
        type="button"
        onClick={() => onSubmit(answers)}
        disabled={!allAnswered}
        className="inline-flex items-center gap-2 rounded-full bg-accent px-7 py-3 text-sm font-bold text-white transition-all duration-200 hover:bg-accent-deep hover:scale-105 disabled:cursor-not-allowed disabled:opacity-40"
      >
        <Send className="h-4 w-4" /> Отправить викторину
      </button>
      {!allAnswered && <p className="text-xs text-fog">Отправка станет доступна, когда отвечены все вопросы.</p>}
    </div>
  );
}
