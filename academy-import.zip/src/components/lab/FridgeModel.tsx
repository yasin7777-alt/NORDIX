import { useState } from 'react';

interface FridgePart {
  id: string;
  label: string;
  role: string;
  facts: string[];
}

const PARTS: FridgePart[] = [
  {
    id: 'evaporator',
    label: 'Испаритель',
    role: 'Теплообменник внутри камеры: хладагент кипит при низком давлении и забирает тепло продукта и воздуха.',
    facts: ['Рабочая температура кипения в бытовой камере около −23…−15 °C', 'Иней на поверхности — нормальное следствие минусовой температуры кипения', 'Перегрев паров на выходе 4–8 K защищает компрессор'],
  },
  {
    id: 'compressor',
    label: 'Компрессор',
    role: 'Сердце машины: всасывает пар из испарителя, сжимает его и нагнетает в конденсатор, создавая разность давлений.',
    facts: ['В быту чаще поршневой герметичный компрессор', 'Пусковые токи в 3–5 раз выше рабочих', 'Любит перегрев на всасывании и не прощает жидкость'],
  },
  {
    id: 'condenser',
    label: 'Конденсатор',
    role: 'Оребрённая решётка на задней стенке: отдаёт тепло кухни, пар конденсируется в жидкость.',
    facts: ['Температура конденсации выше температуры кухни на 10–15 K', 'Пыль на рёбрах поднимает давление конденсации', 'Зона переохлаждения даёт запас жидкости'],
  },
  {
    id: 'capillary',
    label: 'Капиллярная трубка',
    role: 'Дроссель бытовой машины: тонкая трубка роняет давление жидкости до давления испарения и дозирует подачу.',
    facts: ['Производительность постоянная, подобрана заводом', 'Чувствительна к влаге и грязи — нужен фильтр-осушитель', 'После остановки системы давления выравниваются через капилляр'],
  },
  {
    id: 'filter',
    label: 'Фильтр-осушитель',
    role: 'Патрон с адсорбентом: ловит влагу и механические частицы перед дросселем.',
    facts: ['Влага в контуре = ледяные пробки и кислота', 'Меняется при каждом вскрытии контура', 'Ставится между конденсатором и капилляром'],
  },
  {
    id: 'thermostat',
    label: 'Термостат',
    role: 'Держит уставку температуры камеры: замыкает и размыкает цепь компрессора.',
    facts: ['Цикличность «пуск–останов» — норма для быта', 'Частые пуски или непрерывная работа — признак неисправности', 'В современных моделях заменён электронным контроллером'],
  },
];

export function FridgeModel() {
  const [selected, setSelected] = useState<string>('compressor');
  const part = PARTS.find((p) => p.id === selected) as FridgePart;

  const partClass = (id: string) =>
    `cursor-pointer transition-all duration-200 ${selected === id ? 'opacity-100' : 'opacity-70 hover:opacity-100'}`;

  return (
    <div className="grid gap-6 lg:grid-cols-[minmax(0,420px)_1fr]">
      <div className="rounded-2xl border border-line bg-steel p-4">
        <svg viewBox="0 0 420 540" className="w-full" role="img" aria-label="Интерактивная модель холодильника">
          {/* корпус */}
          <rect x="70" y="20" width="260" height="420" rx="18" fill="#101318" stroke="#2e343d" strokeWidth="3" />
          <rect x="90" y="40" width="220" height="110" rx="10" fill="#171b21" stroke="#2e343d" strokeWidth="2" />
          <text x="200" y="34" textAnchor="middle" fill="#8b939e" fontSize="12" fontFamily="Manrope, sans-serif">холодильная камера</text>
          <line x1="90" y1="200" x2="310" y2="200" stroke="#2e343d" strokeWidth="2" />
          <line x1="90" y1="260" x2="310" y2="260" stroke="#2e343d" strokeWidth="2" />
          <line x1="90" y1="320" x2="310" y2="320" stroke="#2e343d" strokeWidth="2" />

          {/* испаритель */}
          <g className={partClass('evaporator')} onClick={() => setSelected('evaporator')} role="button" aria-label="Испаритель">
            <path
              d="M105 60 h190 v20 h-190 v20 h190 v20 h-190 v20 h190"
              fill="none"
              stroke={selected === 'evaporator' ? '#3d75d8' : '#7aa3ec'}
              strokeWidth="5"
              strokeLinecap="round"
              className={selected === 'evaporator' ? 'flow-line' : ''}
            />
            <text x="200" y="166" textAnchor="middle" fill="#7aa3ec" fontSize="12" fontWeight="700" fontFamily="Manrope, sans-serif">испаритель</text>
          </g>

          {/* термостат */}
          <g className={partClass('thermostat')} onClick={() => setSelected('thermostat')} role="button" aria-label="Термостат">
            <circle cx="290" cy="185" r="14" fill={selected === 'thermostat' ? '#3d75d8' : '#22272f'} stroke="#8b939e" strokeWidth="2" />
            <line x1="290" y1="185" x2="298" y2="177" stroke="#f2f4f7" strokeWidth="2" />
            <text x="262" y="182" textAnchor="end" fill="#8b939e" fontSize="11" fontFamily="Manrope, sans-serif">термостат</text>
          </g>

          {/* конденсатор */}
          <g className={partClass('condenser')} onClick={() => setSelected('condenser')} role="button" aria-label="Конденсатор">
            <path
              d="M345 60 h30 v30 h-30 v30 h30 v30 h-30 v30 h30 v30 h-30 v30 h30 v30 h-30 v30 h30 v30 h-30"
              fill="none"
              stroke={selected === 'condenser' ? '#3d75d8' : '#e0a13c'}
              strokeWidth="5"
              strokeLinecap="round"
              className={selected === 'condenser' ? 'flow-line-slow' : ''}
            />
            <text x="360" y="40" textAnchor="middle" fill="#e0a13c" fontSize="12" fontWeight="700" fontFamily="Manrope, sans-serif">конденсатор</text>
          </g>

          {/* компрессор */}
          <g className={partClass('compressor')} onClick={() => setSelected('compressor')} role="button" aria-label="Компрессор">
            <rect x="110" y="455" width="110" height="60" rx="14" fill={selected === 'compressor' ? '#12233f' : '#22272f'} stroke={selected === 'compressor' ? '#3d75d8' : '#2e343d'} strokeWidth="3" />
            <circle cx="165" cy="485" r="16" fill="none" stroke="#8b939e" strokeWidth="2" />
            <text x="165" y="532" textAnchor="middle" fill="#8b939e" fontSize="12" fontWeight="700" fontFamily="Manrope, sans-serif">компрессор</text>
          </g>

          {/* фильтр */}
          <g className={partClass('filter')} onClick={() => setSelected('filter')} role="button" aria-label="Фильтр-осушитель">
            <rect x="330" y="392" width="46" height="18" rx="9" fill={selected === 'filter' ? '#12233f' : '#22272f'} stroke={selected === 'filter' ? '#3d75d8' : '#2e343d'} strokeWidth="2" />
            <text x="353" y="428" textAnchor="middle" fill="#8b939e" fontSize="11" fontFamily="Manrope, sans-serif">фильтр</text>
          </g>

          {/* капилляр */}
          <g className={partClass('capillary')} onClick={() => setSelected('capillary')} role="button" aria-label="Капиллярная трубка">
            <path d="M330 401 C 250 401 240 430 200 430 C 150 430 120 400 90 380 C 70 366 60 300 60 200 C 60 140 70 100 105 90" fill="none" stroke={selected === 'capillary' ? '#3d75d8' : '#8b939e'} strokeWidth="2.5" strokeDasharray="4 4" />
            <text x="60" y="470" textAnchor="start" fill="#8b939e" fontSize="11" fontFamily="Manrope, sans-serif">капилляр</text>
          </g>

          {/* контурные линии */}
          <path d="M165 455 V 440 C 165 420 345 420 345 400 V 380" fill="none" stroke="#e0a13c" strokeWidth="3" opacity="0.7" />
          <path d="M105 140 C 60 160 60 420 110 470" fill="none" stroke="#3d75d8" strokeWidth="3" opacity="0.7" />
        </svg>
        <p className="mt-2 text-center text-xs text-fog">Нажимайте на узлы модели, чтобы изучить назначение детали</p>
      </div>

      <div className="rounded-2xl border border-line bg-coal p-6">
        <p className="text-xs font-bold uppercase tracking-widest text-fog">Выбранный узел</p>
        <h3 className="mt-1 font-display text-2xl font-bold text-paper">{part.label}</h3>
        <p className="mt-3 leading-relaxed text-silver">{part.role}</p>
        <ul className="mt-4 space-y-2">
          {part.facts.map((fact) => (
            <li key={fact} className="flex gap-3 rounded-lg border border-line bg-steel px-4 py-2.5 text-sm text-silver">
              <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-accent" />
              {fact}
            </li>
          ))}
        </ul>
        <div className="mt-5 flex flex-wrap gap-2">
          {PARTS.map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => setSelected(p.id)}
              className={`rounded-full border px-3 py-1.5 text-xs font-bold transition-all duration-150 ${
                selected === p.id
                  ? 'border-accent bg-accent text-white'
                  : 'border-line bg-steel text-silver hover:border-accent hover:text-paper'
              }`}
            >
              {p.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
