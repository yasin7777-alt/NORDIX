import { useState } from 'react';
import { Activity, Gauge } from 'lucide-react';

interface FaultScenario {
  id: string;
  title: string;
  readings: { label: string; value: string; status: 'low' | 'high' | 'norm' }[];
  options: string[];
  correct: number;
  explain: string;
}

const SCENARIOS: FaultScenario[] = [
  {
    id: 'leak',
    title: 'Сценарий 1. Витрина не держит температуру',
    readings: [
      { label: 'Давление НС', value: '0,6 бар (норма 1,8)', status: 'low' },
      { label: 'Давление ВС', value: '9 бар (норма 14)', status: 'low' },
      { label: 'Смотровое стекло', value: 'пузырьки и пена', status: 'high' },
      { label: 'Перегрев', value: '16 K (норма 5–7)', status: 'high' },
    ],
    options: ['Утечка хладагента / недозаправка', 'Загрязнён конденсатор', 'Заклинил компрессор', 'Неисправен вентилятор испарителя'],
    correct: 0,
    explain:
      'Оба давления ниже нормы, пузырьки в стекле и высокий перегрев — классическая картина нехватки хладагента: ищем утечку течеискателем, устраняем, вакуумируем и заправляем по массе.',
  },
  {
    id: 'condenser',
    title: 'Сценарий 2. Компрессор горячий, ток выше номинала',
    readings: [
      { label: 'Давление ВС', value: '22 бар (норма 16)', status: 'high' },
      { label: 'Температура конденсации', value: '+58 °C (норма +42)', status: 'high' },
      { label: 'Ток компрессора', value: '12,4 А (ном. 9,5)', status: 'high' },
      { label: 'Переохлаждение', value: '2 K (норма 4–6)', status: 'low' },
    ],
    options: ['Недозаправка хладагента', 'Загрязнён конденсатор или не работает вентилятор обдува', 'Неисправен ТРВ, переподача', 'Норма для жаркого дня'],
    correct: 1,
    explain:
      'Высокое давление и температура конденсации при повышенном токе говорят о плохом теплосъёме: грязное оребрение или остановленный вентилятор. Чистим конденсатор и проверяем обдув.',
  },
  {
    id: 'trv',
    title: 'Сценарий 3. Камера выходит на режим часами',
    readings: [
      { label: 'Давление НС', value: '1,1 бар (норма 2,4)', status: 'low' },
      { label: 'Перегрев', value: '14 K (норма 6)', status: 'high' },
      { label: 'Иней на испарителе', value: 'только на первой трети', status: 'low' },
      { label: 'Давление ВС', value: 'в норме', status: 'norm' },
    ],
    options: ['ТРВ недодаёт хладагент (или забит фильтр-осушитель)', 'Перезаправка контура', 'Неисправен термостат камеры', 'Воздух в контуре'],
    correct: 0,
    explain:
      'Низкое НС при высоком перегреве и частичном инее — испаритель голодает: ТРВ недодаёт жидкость либо забит фильтр-осушитель. Проверяем фильтр, регулировку/состояние ТРВ.',
  },
];

const STATUS_STYLE: Record<FaultScenario['readings'][number]['status'], string> = {
  low: 'text-accent-soft',
  high: 'text-bad',
  norm: 'text-ok',
};

export function FaultSimulator() {
  const [scenarioIndex, setScenarioIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [checked, setChecked] = useState<Record<string, boolean>>({});

  const scenario = SCENARIOS[scenarioIndex];
  const answer = answers[scenario.id] ?? null;
  const isChecked = Boolean(checked[scenario.id]);
  const solved = isChecked && answer === scenario.correct;

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap gap-2">
        {SCENARIOS.map((s, i) => (
          <button
            key={s.id}
            type="button"
            onClick={() => setScenarioIndex(i)}
            className={`rounded-full border px-4 py-2 text-xs font-bold transition-all duration-150 ${
              scenarioIndex === i
                ? 'border-accent bg-accent text-white'
                : 'border-line bg-steel text-silver hover:border-accent hover:text-paper'
            }`}
          >
            Сценарий {i + 1}
          </button>
        ))}
      </div>

      <div className="rounded-2xl border border-line bg-steel p-5">
        <h4 className="flex items-center gap-2 font-display text-lg font-bold text-paper">
          <Activity className="h-5 w-5 text-accent-soft" />
          {scenario.title}
        </h4>
        <div className="mt-4 grid gap-2 sm:grid-cols-2">
          {scenario.readings.map((reading) => (
            <div key={reading.label} className="flex items-center justify-between gap-3 rounded-lg border border-line bg-coal px-4 py-2.5">
              <span className="flex items-center gap-2 text-xs font-bold text-fog">
                <Gauge className="h-4 w-4" />
                {reading.label}
              </span>
              <span className={`text-sm font-bold ${STATUS_STYLE[reading.status]}`}>{reading.value}</span>
            </div>
          ))}
        </div>

        <p className="mt-5 text-sm font-bold text-paper">Ваш диагноз:</p>
        <div className="mt-2 grid gap-2">
          {scenario.options.map((option, i) => (
            <label
              key={option}
              className={`flex cursor-pointer items-center gap-3 rounded-lg border px-4 py-2.5 text-sm transition-colors duration-150 ${
                isChecked
                  ? i === scenario.correct
                    ? 'border-ok/60 bg-ok/10 text-paper'
                    : answer === i
                      ? 'border-bad/60 bg-bad/10 text-paper'
                      : 'border-line bg-coal text-fog'
                  : answer === i
                    ? 'border-accent bg-accent/15 text-paper'
                    : 'border-line bg-coal text-silver hover:border-accent/50'
              }`}
            >
              <input
                type="radio"
                name={`fault-${scenario.id}`}
                className="accent-[#3d75d8]"
                checked={answer === i}
                onChange={() => {
                  setAnswers((prev) => ({ ...prev, [scenario.id]: i }));
                  setChecked((prev) => ({ ...prev, [scenario.id]: false }));
                }}
              />
              {option}
            </label>
          ))}
        </div>
        <button
          type="button"
          onClick={() => setChecked((prev) => ({ ...prev, [scenario.id]: true }))}
          disabled={answer === null}
          className="mt-4 rounded-full bg-accent px-6 py-2.5 text-sm font-bold text-white transition-all duration-200 hover:bg-accent-deep hover:scale-105 disabled:cursor-not-allowed disabled:opacity-40"
        >
          Поставить диагноз
        </button>
        {isChecked && (
          <p className={`mt-3 rounded-lg border px-4 py-3 text-sm leading-relaxed ${solved ? 'border-ok/50 bg-ok/10 text-ok' : 'border-bad/50 bg-bad/10 text-bad'}`}>
            {scenario.explain}
          </p>
        )}
      </div>
    </div>
  );
}
