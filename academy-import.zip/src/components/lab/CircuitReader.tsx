import { useState } from 'react';

interface CircuitElement {
  id: string;
  code: string;
  name: string;
  role: string;
}

const ELEMENTS: CircuitElement[] = [
  { id: 'qf', code: 'QF', name: 'Автоматический выключатель', role: 'Защищает линию от перегрузки и короткого замыкания. Точка ручного отключения питания установки.' },
  { id: 'sf', code: 'SF', name: 'Термостат (датчик-реле температуры)', role: 'Контакт, управляемый температурой камеры: замкнул — компрессор работает, разомкнул — останов.' },
  { id: 'kk', code: 'KK', name: 'Реле защиты компрессора', role: 'Тепловая защита мотора: размыкает цепь при перегреве или заклинивании, спасая обмотки.' },
  { id: 'km', code: 'KM', name: 'Пусковое реле / контактор', role: 'Коммутирует пусковую обмотку или силовую цепь мотора по команде термостата и защиты.' },
  { id: 'm', code: 'M', name: 'Электродвигатель компрессора', role: 'Привод компрессора: превращает электрическую энергию в работу сжатия пара.' },
];

const SCHEMA_QUESTION = {
  q: 'Прочитайте схему: термостат SF разомкнул контакт. Что произойдёт?',
  options: [
    'Компрессор продолжит работу, отключится только освещение',
    'Цепь управления разорвётся, контактор отпустит, компрессор остановится',
    'Сработает автомат QF',
    'Мотор перейдёт на пусковую обмотку',
  ],
  correct: 1,
  explain:
    'Термостат стоит в цепи управления до контактора и защиты: разомкнутый контакт снимает питание с цепи управления, контактор отпускает и мотор останавливается до следующего падения температуры.',
};

export function CircuitReader() {
  const [selected, setSelected] = useState<string>('qf');
  const [answer, setAnswer] = useState<number | null>(null);
  const [checked, setChecked] = useState(false);
  const element = ELEMENTS.find((e) => e.id === selected) as CircuitElement;

  const box = (id: string, x: number, label: string) => {
    const active = selected === id;
    return (
      <g key={id} className="cursor-pointer" onClick={() => setSelected(id)} role="button" aria-label={label}>
        <rect
          x={x}
          y={70}
          width="64"
          height="44"
          rx="8"
          fill={active ? '#12233f' : '#171b21'}
          stroke={active ? '#3d75d8' : '#2e343d'}
          strokeWidth={active ? 3 : 1.5}
          className="transition-all duration-200"
        />
        <text x={x + 32} y={97} textAnchor="middle" fill="#f2f4f7" fontSize="16" fontWeight="800" fontFamily="Manrope, sans-serif">
          {label}
        </text>
      </g>
    );
  };

  return (
    <div className="space-y-5">
      <div className="rounded-2xl border border-line bg-steel p-5">
        <svg viewBox="0 0 640 180" className="w-full" role="img" aria-label="Однолинейная схема питания компрессора">
          <line x1="20" y1="92" x2="70" y2="92" stroke="#e0a13c" strokeWidth="4" />
          <line x1="134" y1="92" x2="190" y2="92" stroke="#e0a13c" strokeWidth="4" className="flow-line-slow" />
          <line x1="254" y1="92" x2="310" y2="92" stroke="#e0a13c" strokeWidth="4" className="flow-line-slow" />
          <line x1="374" y1="92" x2="430" y2="92" stroke="#e0a13c" strokeWidth="4" className="flow-line-slow" />
          <line x1="494" y1="92" x2="560" y2="92" stroke="#e0a13c" strokeWidth="4" className="flow-line-slow" />
          <text x="20" y="70" fill="#8b939e" fontSize="13" fontFamily="Manrope, sans-serif">L (фаза)</text>
          <text x="560" y="70" fill="#8b939e" fontSize="13" fontFamily="Manrope, sans-serif">к мотору</text>
          <line x1="20" y1="150" x2="600" y2="150" stroke="#3d75d8" strokeWidth="4" />
          <text x="20" y="172" fill="#8b939e" fontSize="13" fontFamily="Manrope, sans-serif">N (ноль)</text>
          {box('qf', 70, 'QF')}
          {box('sf', 190, 'SF')}
          {box('kk', 310, 'KK')}
          {box('km', 430, 'KM')}
          <g className="cursor-pointer" onClick={() => setSelected('m')} role="button" aria-label="Электродвигатель компрессора">
            <circle cx="590" cy="92" r="26" fill={selected === 'm' ? '#12233f' : '#171b21'} stroke={selected === 'm' ? '#3d75d8' : '#2e343d'} strokeWidth={selected === 'm' ? 3 : 1.5} />
            <text x="590" y="99" textAnchor="middle" fill="#f2f4f7" fontSize="18" fontWeight="800" fontFamily="Manrope, sans-serif">M</text>
          </g>
        </svg>
        <p className="mt-2 text-center text-xs text-fog">Однолинейная схема цепи компрессора: нажмите элемент, чтобы прочитать его назначение</p>
      </div>

      <div className="rounded-2xl border border-line bg-coal p-5">
        <p className="text-xs font-bold uppercase tracking-widest text-fog">Элемент схемы</p>
        <h4 className="mt-1 font-display text-xl font-bold text-paper">
          {element.code} · {element.name}
        </h4>
        <p className="mt-2 text-sm leading-relaxed text-silver">{element.role}</p>
      </div>

      <div className="rounded-2xl border border-accent/40 bg-accent/10 p-5">
        <h4 className="font-display text-lg font-bold text-paper">{SCHEMA_QUESTION.q}</h4>
        <div className="mt-3 grid gap-2">
          {SCHEMA_QUESTION.options.map((option, i) => (
            <label
              key={option}
              className={`flex cursor-pointer items-center gap-3 rounded-lg border px-4 py-2.5 text-sm transition-colors duration-150 ${
                checked
                  ? i === SCHEMA_QUESTION.correct
                    ? 'border-ok/60 bg-ok/10 text-paper'
                    : answer === i
                      ? 'border-bad/60 bg-bad/10 text-paper'
                      : 'border-line bg-steel text-fog'
                  : answer === i
                    ? 'border-accent bg-accent/15 text-paper'
                    : 'border-line bg-steel text-silver hover:border-accent/50'
              }`}
            >
              <input
                type="radio"
                name="schema-q"
                className="accent-[#3d75d8]"
                checked={answer === i}
                onChange={() => {
                  setAnswer(i);
                  setChecked(false);
                }}
              />
              {option}
            </label>
          ))}
        </div>
        <button
          type="button"
          onClick={() => setChecked(true)}
          disabled={answer === null}
          className="mt-3 rounded-full bg-accent px-6 py-2.5 text-sm font-bold text-white transition-all duration-200 hover:bg-accent-deep hover:scale-105 disabled:cursor-not-allowed disabled:opacity-40"
        >
          Проверить чтение схемы
        </button>
        {checked && (
          <p className={`mt-3 rounded-lg border px-4 py-3 text-sm leading-relaxed ${answer === SCHEMA_QUESTION.correct ? 'border-ok/50 bg-ok/10 text-ok' : 'border-bad/50 bg-bad/10 text-bad'}`}>
            {SCHEMA_QUESTION.explain}
          </p>
        )}
      </div>
    </div>
  );
}
