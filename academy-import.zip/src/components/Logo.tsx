interface LogoProps { size?: 'sm' | 'md' | 'lg'; light?: boolean; }
const base = import.meta.env.BASE_URL.replace(/academy\/$/, '');
export function LogoMark({className=''}:{className?:string}) { return <img src={base+'favicon.svg'} className={`${className} object-contain brightness-0`} alt="" aria-hidden="true"/>; }
export function Logo({size='md'}:LogoProps) { return <span className="inline-flex select-none items-center gap-2.5"><span className="flex h-10 w-14 items-center justify-center rounded-xl bg-black"><img src={base+'favicon.svg'} className="h-8 w-10 object-contain" alt=""/></span><span className={`font-display font-extrabold tracking-tight text-black ${size==='lg'?'text-2xl':size==='sm'?'text-base':'text-xl'}`}>NORDIX</span></span>; }
