import { useEffect, useState } from 'react';
import { Link, Navigate, useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, ArrowRight, CheckCircle2, ChevronLeft } from 'lucide-react';
import { getCourse, getCourseLessons, getLesson } from '../lib/content/courses';
import { coursePercent } from '../lib/progress';
import { useProgress } from '../lib/ProgressContext';
import { scoreQuiz } from '../lib/quiz';
import type { QuizResult } from '../lib/quiz';
import type { StageId } from '../lib/types';
import { LessonSidebar } from '../components/lesson/LessonSidebar';
import { StageStepper } from '../components/lesson/StageStepper';
import { TheoryStage } from '../components/lesson/TheoryStage';
import { VideoStage } from '../components/lesson/VideoStage';
import { PracticeStage } from '../components/lesson/PracticeStage';
import { QuizStage } from '../components/lesson/QuizStage';
import { ResultStage } from '../components/lesson/ResultStage';

export function Lesson() {
  const { courseId = '', lessonId = '' } = useParams();
  const navigate = useNavigate();
  const { state, completeLesson, recordAttempt, markSafetyPassed } = useProgress();

  const course = getCourse(courseId);
  const lessons = getCourseLessons(courseId);
  const lesson = getLesson(courseId, lessonId);

  const [stage, setStage] = useState<StageId>('theory');
  const [quizResult, setQuizResult] = useState<QuizResult | null>(null);

  useEffect(() => {
    setStage('theory');
    setQuizResult(null);
    window.scrollTo({ top: 0 });
  }, [lessonId]);

  if (!course || lessons.length === 0 || !lesson) {
    return <Navigate to="/education" replace />;
  }

  const index = lessons.findIndex((l) => l.id === lesson.id);
  const prevLesson = index > 0 ? lessons[index - 1] : null;
  const nextLesson = index < lessons.length - 1 ? lessons[index + 1] : null;
  const completedIds = state.completed[course.id] ?? [];
  const isCompleted = completedIds.includes(lesson.id);
  const percent = coursePercent(state, course.id, lessons.length);

  const submitQuiz = (answers: (number | null)[]) => {
    const result = scoreQuiz(lesson.quiz, answers);
    recordAttempt({
      courseId: course.id,
      courseTitle: course.title,
      lessonId: lesson.id,
      lessonTitle: lesson.title,
      correct: result.correct,
      total: result.total,
      percent: result.percent,
      passed: result.passed,
    });
    setQuizResult(result);
    setStage('result');
  };

  return (
    <div className="mx-auto max-w-7xl px-4 pb-24 pt-24 sm:px-6 lg:px-8">
      <a
        href={import.meta.env.BASE_URL.replace(/academy\/$/, '') + '#directions'}
        className="inline-flex items-center gap-2 text-sm font-bold text-fog transition-colors hover:text-accent-soft"
      >
        <ChevronLeft className="h-4 w-4" /> Каталог курсов
      </a>

      <div className="mt-4 grid gap-8 lg:grid-cols-[320px_minmax(0,1fr)]">
        <LessonSidebar
          course={course}
          lessons={lessons}
          currentLessonId={lesson.id}
          completedIds={completedIds}
          percent={percent}
        />

        <main>
          <p className="font-display text-xs font-bold uppercase tracking-[0.25em] text-accent-soft">
            Урок {lesson.num} из {lessons.length}
          </p>
          <h1 className="mt-2 font-display text-3xl font-extrabold leading-tight text-paper sm:text-4xl">
            {lesson.title}
          </h1>

          <div className="mt-6">
            <StageStepper current={stage} quizDone={quizResult !== null} onSelect={setStage} />
          </div>

          <div className="mt-8 rounded-2xl border border-line bg-coal p-6 sm:p-8">
            {stage === 'theory' && <TheoryStage lesson={lesson} />}
            {stage === 'video' && <VideoStage lesson={lesson} />}
            {stage === 'practice' && (
              <PracticeStage task={lesson.practice} safetyPassed={state.safetyPassed} onSafetyPassed={markSafetyPassed} />
            )}
            {stage === 'quiz' && <QuizStage key={lesson.id} questions={lesson.quiz} onSubmit={submitQuiz} />}
            {stage === 'result' && quizResult && (
              <ResultStage
                questions={lesson.quiz}
                result={quizResult}
                lessonTitle={lesson.title}
                onRetry={() => {
                  setQuizResult(null);
                  setStage('quiz');
                }}
                onNext={nextLesson ? () => navigate(`/learn/${course.id}/${nextLesson.id}`) : null}
              />
            )}
          </div>

          {/* нижняя навигация урока */}
          <div className="mt-8 grid gap-3 sm:grid-cols-3">
            {prevLesson ? (
              <Link
                to={`/learn/${course.id}/${prevLesson.id}`}
                className="group flex items-center gap-3 rounded-2xl border border-line bg-coal px-5 py-4 transition-all duration-200 hover:border-accent"
              >
                <ArrowLeft className="h-5 w-5 shrink-0 text-fog transition-colors group-hover:text-accent-soft" />
                <span className="min-w-0">
                  <span className="block text-xs font-bold uppercase tracking-wider text-fog">Предыдущий урок</span>
                  <span className="block truncate text-sm font-bold text-silver">{prevLesson.title}</span>
                </span>
              </Link>
            ) : (
              <span className="hidden sm:block" />
            )}

            <button
              type="button"
              onClick={() => completeLesson(course.id, lesson.id)}
              disabled={isCompleted || !quizResult?.passed}
              className={`flex items-center justify-center gap-2 rounded-2xl px-5 py-4 font-bold transition-all duration-200 ${
                isCompleted
                  ? 'cursor-default border border-ok/50 bg-ok/10 text-ok'
                  : 'bg-accent text-white hover:bg-accent-deep hover:scale-[1.02]'
              }`}
            >
              <CheckCircle2 className="h-5 w-5" />
              {isCompleted ? 'Урок пройден' : quizResult?.passed ? 'Завершить урок' : 'Пройдите викторину'}
            </button>

            {nextLesson ? (
              <Link
                to={`/learn/${course.id}/${nextLesson.id}`}
                className="group flex items-center justify-end gap-3 rounded-2xl border border-line bg-coal px-5 py-4 text-right transition-all duration-200 hover:border-accent"
              >
                <span className="min-w-0">
                  <span className="block text-xs font-bold uppercase tracking-wider text-fog">Следующий урок</span>
                  <span className="block truncate text-sm font-bold text-silver">{nextLesson.title}</span>
                </span>
                <ArrowRight className="h-5 w-5 shrink-0 text-fog transition-colors group-hover:text-accent-soft" />
              </Link>
            ) : (
              <Link
                to="/progress"
                className="group flex items-center justify-end gap-3 rounded-2xl border border-accent/50 bg-accent/10 px-5 py-4 text-right transition-all duration-200 hover:border-accent"
              >
                <span className="min-w-0">
                  <span className="block text-xs font-bold uppercase tracking-wider text-fog">Курс завершён?</span>
                  <span className="block truncate text-sm font-bold text-accent-soft">Мой прогресс и сертификат</span>
                </span>
                <ArrowRight className="h-5 w-5 shrink-0 text-accent-soft" />
              </Link>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
