import { useState } from 'react';
import { motion } from 'framer-motion';
import { Activity, Cpu, FlaskConical, GitCompareArrows, Network, Refrigerator } from 'lucide-react';
import { CycleDiagram } from '../components/CycleDiagram';
import { FridgeModel } from '../components/lab/FridgeModel';
import { CircuitReader } from '../components/lab/CircuitReader';
import { FaultSimulator } from '../components/lab/FaultSimulator';
import { PracticeStage } from '../components/lesson/PracticeStage';
import { useProgress } from '../lib/ProgressContext';
import type { CycleNodeId, PracticeTask } from '../lib/types';

type LabSection = 'model' | 'cycle' | 'match' | 'circuit' | 'faults' | 'tasks';

const SECTIONS: { id: LabSection; label: string; icon: typeof Refrigerator }[] = [
  { id: 'model', label: 'Модель холодильника', icon: Refrigerator },
  { id: 'cycle', label: 'Холодильный цикл', icon: GitCompareArrows },
  { id: 'match', label: 'Компоненты и функции', icon: Network },
  { id: 'circuit', label: 'Электрическая схема', icon: Cpu },
  { id: 'faults', label: 'Неисправности', icon: Activity },
  { id: 'tasks', label: 'Практические задания', icon: FlaskConical },
];

const CYCLE_PROCESSES: { id: CycleNodeId; title: string; text: string }[] = [
  {
    id: 'compressor',
    title: '1. Сжатие',
    text: 'Компрессор всасывает перегретый пар низкого давления и сжимает его: давление и температура растут до уровня, при котором тепло можно отдать среде.',
  },
  {
    id: 'condenser',
    title: '2. Конденсация',
    text: 'В конденсаторе пар снимает перегрев, конденсируется и переохлаждается, отдавая тепло воздуху или воде. Жидкость готова к дросселированию.',
  },
  {
    id: 'expansion',
    title: '3. Дросселирование',
    text: 'ТРВ или капилляр роняют давление: часть жидкости вскипает сразу, температура смеси падает до температуры испарения.',
  },
  {
    id: 'evaporator',
    title: '4. Испарение',
    text: 'В испарителе хладагент кипит, забирая тепло охлаждаемого объёма, и выходит перегретым паром — круг замыкается на всасывании компрессора.',
  },
];

const LAB_MATCH_TASK: PracticeTask = {
  kind: 'match',
  title: 'Сопоставьте компонент и его функцию',
  prompt: 'Тренажёр лаборатории: соедините узел контура с его назначением.',
  pairs: [
    { left: 'Компрессор', right: 'Сжимает пар, создаёт разность давлений ВС и НС' },
    { left: 'Конденсатор', right: 'Конденсирует пар и отдаёт тепло среде' },
    { left: 'ТРВ', right: 'Дросселирует жидкость и держит перегрев' },
    { left: 'Испаритель', right: 'Кипит при низком давлении и забирает тепло' },
    { left: 'Ресивер', right: 'Хранит запас жидкого хладагента' },
  ],
};

const LAB_ORDER_TASK: PracticeTask = {
  kind: 'order',
  title: 'Практическое задание: собери цикл',
  prompt: 'Выстройте процессы в порядке движения хладагента по контуру, начиная с компрессора. Задание доступно после инструктажа по безопасности.',
  steps: [
    'Компрессор сжимает перегретый пар',
    'Конденсатор отдаёт тепло и конденсирует пар',
    'Дроссель роняет давление жидкости',
    'Испаритель кипит и забирает тепло камеры',
  ],
};

export function Lab() {
  const [section, setSection] = useState<LabSection>('model');
  const [process, setProcess] = useState<CycleNodeId>('compressor');
  const { state, markSafetyPassed } = useProgress();
  const activeProcess = CYCLE_PROCESSES.find((p) => p.id === process) as (typeof CYCLE_PROCESSES)[number];

  return (
    <div className="mx-auto max-w-7xl px-4 pb-24 pt-28 sm:px-6 lg:px-8">
      <p className="text-xs font-bold uppercase tracking-[0.25em] text-accent-soft">Виртуальная лаборатория</p>
      <h1 className="mt-3 font-display text-4xl font-extrabold text-paper sm:text-5xl">NORDIX LAB</h1>
      <p className="mt-4 max-w-3xl leading-relaxed text-silver">
        Безопасная виртуальная среда для отработки навыков: рассматривайте модель холодильника, нажимайте на компоненты,
        наблюдайте анимацию цикла, читайте схемы и анализируйте неисправности.
      </p>

      <div className="mt-8 flex flex-wrap gap-2" role="tablist" aria-label="Разделы лаборатории">
        {SECTIONS.map((s) => (
          <button
            key={s.id}
            type="button"
            role="tab"
            aria-selected={section === s.id}
            onClick={() => setSection(s.id)}
            className={`inline-flex items-center gap-2 rounded-full border px-4 py-2 text-sm font-bold transition-all duration-200 ${
              section === s.id
                ? 'border-accent bg-accent text-white'
                : 'border-line bg-steel text-silver hover:border-accent hover:text-paper'
            }`}
          >
            <s.icon className="h-4 w-4" />
            {s.label}
          </button>
        ))}
      </div>

      <motion.div
        key={section}
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.35 }}
        className="mt-8"
      >
        {section === 'model' && <FridgeModel />}

        {section === 'cycle' && (
          <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_360px]">
            <div className="rounded-2xl border border-line bg-steel p-6">
              <CycleDiagram highlight={process} />
            </div>
            <div className="space-y-3">
              {CYCLE_PROCESSES.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => setProcess(p.id)}
                  className={`w-full rounded-xl border p-4 text-left transition-all duration-200 ${
                    process === p.id ? 'border-accent bg-accent/15' : 'border-line bg-coal hover:border-accent/50'
                  }`}
                >
                  <h3 className="font-display text-sm font-bold text-paper">{p.title}</h3>
                  {process === p.id && <p className="mt-2 text-sm leading-relaxed text-silver">{p.text}</p>}
                </button>
              ))}
              <p className="rounded-xl border border-line bg-coal p-4 text-xs leading-relaxed text-fog">
                Оранжевая линия — сторона высокого давления, синяя — низкого. Анимация потока показывает направление
                движения хладагента.
              </p>
            </div>
          </div>
        )}

        {section === 'match' && (
          <div className="rounded-2xl border border-line bg-coal p-6 sm:p-8">
            <PracticeStage task={LAB_MATCH_TASK} safetyPassed={state.safetyPassed} onSafetyPassed={markSafetyPassed} />
          </div>
        )}

        {section === 'circuit' && (state.safetyPassed ? <CircuitReader /> : <PracticeGateNote onOpenSafety={() => setSection('tasks')} />)}

        {section === 'faults' &&
          (state.safetyPassed ? (
            <FaultSimulator />
          ) : (
            <PracticeGateNote onOpenSafety={() => setSection('tasks')} />
          ))}

        {section === 'tasks' && (
          <div className="space-y-6">
            <div className="rounded-2xl border border-line bg-coal p-6 sm:p-8">
              <PracticeStage task={LAB_ORDER_TASK} safetyPassed={state.safetyPassed} onSafetyPassed={markSafetyPassed} />
            </div>
            {state.safetyPassed && (
              <div className="rounded-2xl border border-line bg-coal p-6 sm:p-8">
                <h3 className="font-display text-xl font-bold text-paper">Практическое задание: диагностика по датчикам</h3>
                <p className="mt-2 text-sm text-fog">Перейдите к разделу «Неисправности» и разберите все три сценария.</p>
                <button
                  type="button"
                  onClick={() => setSection('faults')}
                  className="mt-4 rounded-full bg-accent px-6 py-2.5 text-sm font-bold text-white transition-all duration-200 hover:bg-accent-deep hover:scale-105"
                >
                  Открыть симулятор неисправностей
                </button>
              </div>
            )}
          </div>
        )}
      </motion.div>
    </div>
  );
}

function PracticeGateNote({ onOpenSafety }: { onOpenSafety: () => void }) {
  return (
    <div className="rounded-2xl border border-warn/40 bg-warn/5 p-8 text-center">
      <Activity className="mx-auto h-10 w-10 text-warn" />
      <h3 className="mt-4 font-display text-2xl font-bold text-paper">Раздел открывается после инструктажа</h3>
      <p className="mx-auto mt-3 max-w-xl text-sm leading-relaxed text-silver">
        Анализ неисправностей и практические задания доступны после обязательного знакомства с техникой безопасности.
        Пройдите короткий инструктаж в разделе «Практические задания».
      </p>
      <button
        type="button"
        onClick={onOpenSafety}
        className="mt-6 rounded-full bg-warn px-7 py-3 text-sm font-bold text-black transition-all duration-200 hover:scale-105 hover:bg-warn/90"
      >
        Пройти инструктаж
      </button>
    </div>
  );
}
