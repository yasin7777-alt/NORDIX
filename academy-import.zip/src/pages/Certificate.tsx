import { useEffect } from 'react';
import { Link, Navigate, useParams } from 'react-router-dom';
import { Printer } from 'lucide-react';
import { Logo, LogoMark } from '../components/Logo';
import { getCourse } from '../lib/content/courses';
import { coursePercent, isCourseComplete } from '../lib/progress';
import { useProgress } from '../lib/ProgressContext';

export function Certificate() {
  const { courseId = '' } = useParams();
  const { state, grantCertificate } = useProgress();
  const course = getCourse(courseId);

  const total = course ? course.lessonTitles.length : 0;
  const complete = course ? isCourseComplete(state, course.id, total) : false;

  useEffect(() => {
    if (course && complete && !state.certificates[course.id]) {
      grantCertificate(course.id);
    }
  }, [course, complete, state.certificates, grantCertificate]);

  if (!course) return <Navigate to="/progress" replace />;

  if (!complete) {
    const percent = coursePercent(state, course.id, total);
    return (
      <div className="mx-auto max-w-3xl px-4 pb-24 pt-32 text-center sm:px-6">
        <h1 className="font-display text-3xl font-extrabold text-paper sm:text-4xl">Сертификат ещё не открыт</h1>
        <p className="mt-4 text-silver">
          Курс «{course.title}» пройден на {percent}%. Сертификат станет доступен после завершения всех {total} уроков,
          включая итоговую проверку.
        </p>
        <div className="mx-auto mt-6 h-2 max-w-md overflow-hidden rounded-full bg-steel">
          <div className="h-full rounded-full bg-accent transition-all duration-500" style={{ width: `${percent}%` }} />
        </div>
        <Link
          to="/education"
          className="mt-8 inline-block rounded-full bg-accent px-7 py-3 font-bold text-white transition-all duration-200 hover:bg-accent-deep hover:scale-105"
        >
          Продолжить обучение
        </Link>
      </div>
    );
  }

  const issueDate = state.certificates[course.id] ?? new Date().toISOString();
  const studentName = state.studentName.trim() || 'Студент NORDIX';
  const certificateId = `NX-${course.num}-${issueDate.slice(0, 10).replaceAll('-', '')}`;

  return (
    <div className="mx-auto max-w-4xl px-4 pb-24 pt-28 sm:px-6">
      <div className="no-print mb-6 flex items-center justify-between gap-4">
        <Link to="/progress" className="text-sm font-bold text-fog transition-colors hover:text-accent-soft">
          ← Мой прогресс
        </Link>
        <button
          type="button"
          onClick={() => window.print()}
          className="inline-flex items-center gap-2 rounded-full bg-accent px-6 py-2.5 text-sm font-bold text-white transition-all duration-200 hover:bg-accent-deep hover:scale-105"
        >
          <Printer className="h-4 w-4" /> Печать / PDF
        </button>
      </div>

      <div className="rounded-3xl border-4 border-black bg-white p-8 text-black shadow-2xl sm:p-12">
        <div className="flex items-center justify-between">
          <Logo light={false} />
          <span className="text-accent">
            <LogoMark className="h-10 w-10" />
          </span>
        </div>
        <p className="mt-10 text-center text-xs font-bold uppercase tracking-[0.35em] text-black/60">
          Внутренний сертификат
        </p>
        <h1 className="mt-3 text-center font-display text-3xl font-extrabold sm:text-4xl">{studentName}</h1>
        <p className="mt-4 text-center text-sm leading-relaxed text-black/70">
          полностью прошёл(-ла) курс программы NORDIX
        </p>
        <p className="mt-2 text-center font-display text-xl font-bold text-accent-deep sm:text-2xl">
          «{course.title}»
        </p>
        <p className="mt-4 text-center text-sm text-black/70">
          {total} уроков: теория, видео, интерактивная практика и итоговая проверка знаний
        </p>
        <div className="mt-10 flex items-end justify-between gap-6 border-t border-black/15 pt-6 text-xs text-black/70">
          <div>
            <p className="font-bold uppercase tracking-wider">Дата выдачи</p>
            <p className="mt-1 text-sm font-bold text-black">{new Date(issueDate).toLocaleDateString('ru-RU')}</p>
          </div>
          <div className="text-center">
            <p className="font-bold uppercase tracking-wider">Номер</p>
            <p className="mt-1 text-sm font-bold text-black">{certificateId}</p>
          </div>
          <div className="text-right">
            <p className="font-bold uppercase tracking-wider">NORDIX Education</p>
            <p className="mt-1 font-display text-sm font-bold text-black">образовательная платформа</p>
          </div>
        </div>
        <p className="mt-6 rounded-lg bg-black/5 p-3 text-center text-[11px] leading-relaxed text-black/60">
          Внутренний сертификат NORDIX подтверждает прохождение образовательной программы платформы и не заменяет
          профессиональную квалификацию и допуск к реальным работам.
        </p>
      </div>
    </div>
  );
}
