import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Award, RotateCcw, ShieldCheck, ShieldAlert, User } from 'lucide-react';
import { COURSES } from '../lib/content/courses';
import { coursePercent, isCourseComplete } from '../lib/progress';
import { useProgress } from '../lib/ProgressContext';

export function ProgressPage() {
  const { state, saveStudentName, resetProgress } = useProgress();
  const [nameDraft, setNameDraft] = useState(state.studentName);
  const [saved, setSaved] = useState(false);

  const handleReset = () => {
    if (window.confirm('Сбросить весь прогресс, историю викторин и сертификаты? Действие необратимо.')) {
      resetProgress();
      setNameDraft('');
    }
  };

  return (
    <div className="mx-auto max-w-7xl px-4 pb-24 pt-28 sm:px-6 lg:px-8">
      <p className="text-xs font-bold uppercase tracking-[0.25em] text-accent-soft">Личный кабинет</p>
      <h1 className="mt-3 font-display text-4xl font-extrabold text-paper sm:text-5xl">Мой прогресс</h1>

      <div className="mt-8 grid gap-6 lg:grid-cols-3">
        <div className="rounded-2xl border border-line bg-coal p-6">
          <p className="flex items-center gap-2 text-sm font-bold text-paper">
            <User className="h-4 w-4 text-accent-soft" /> Имя для сертификата
          </p>
          <div className="mt-3 flex gap-2">
            <input
              value={nameDraft}
              onChange={(e) => {
                setNameDraft(e.target.value);
                setSaved(false);
              }}
              placeholder="Иван Северов"
              className="w-full rounded-lg border border-line bg-steel px-4 py-2.5 text-sm text-paper placeholder:text-fog/60 focus:border-accent focus:outline-none"
            />
            <button
              type="button"
              onClick={() => {
                saveStudentName(nameDraft.trim());
                setSaved(true);
              }}
              className="shrink-0 rounded-lg bg-accent px-4 py-2.5 text-sm font-bold text-white transition-all duration-200 hover:bg-accent-deep"
            >
              {saved ? 'Сохранено' : 'Сохранить'}
            </button>
          </div>
          <p className="mt-2 text-xs text-fog">Имя появится во внутренних сертификатах курсов.</p>
        </div>

        <div className="rounded-2xl border border-line bg-coal p-6">
          <p className="flex items-center gap-2 text-sm font-bold text-paper">
            {state.safetyPassed ? <ShieldCheck className="h-4 w-4 text-ok" /> : <ShieldAlert className="h-4 w-4 text-warn" />}
            Инструктаж по безопасности
          </p>
          <p className="mt-3 text-sm leading-relaxed text-silver">
            {state.safetyPassed
              ? 'Пройден. Практические задания и симуляторы лаборатории открыты.'
              : 'Не пройден. Практика курсов и NORDIX LAB откроются после инструктажа.'}
          </p>
          {!state.safetyPassed && (
            <Link to="/lab" className="mt-3 inline-block text-sm font-bold text-accent-soft hover:text-paper">
              Пройти инструктаж в LAB →
            </Link>
          )}
        </div>

        <div className="rounded-2xl border border-bad/40 bg-bad/5 p-6">
          <p className="flex items-center gap-2 text-sm font-bold text-paper">
            <RotateCcw className="h-4 w-4 text-bad" /> Сброс прогресса
          </p>
          <p className="mt-3 text-sm leading-relaxed text-silver">Полностью очищает локальные данные обучения.</p>
          <button
            type="button"
            onClick={handleReset}
            className="mt-3 rounded-lg border border-bad/60 px-4 py-2 text-sm font-bold text-bad transition-all duration-200 hover:bg-bad hover:text-paper"
          >
            Сбросить всё
          </button>
        </div>
      </div>

      <h2 className="mt-14 font-display text-2xl font-extrabold text-paper">Курсы</h2>
      <div className="mt-5 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {COURSES.map((course) => {
          const percent = coursePercent(state, course.id, course.lessonTitles.length);
          const complete = isCourseComplete(state, course.id, course.lessonTitles.length);
          return (
            <div key={course.id} className="rounded-2xl border border-line bg-coal p-5">
              <div className="flex items-start justify-between gap-3">
                <h3 className="font-display text-base font-bold text-paper">{course.title}</h3>
                <span className="font-display text-lg font-extrabold text-accent-soft">{percent}%</span>
              </div>
              <div className="mt-3 h-2 overflow-hidden rounded-full bg-steel">
                <div className="h-full rounded-full bg-accent transition-all duration-500" style={{ width: `${percent}%` }} />
              </div>
              <p className="mt-2 text-xs text-fog">
                {state.completed[course.id]?.length ?? 0} из {course.lessonTitles.length} уроков
              </p>
              {complete ? (
                <Link
                  to={`/certificate/${course.id}`}
                  className="mt-4 inline-flex items-center gap-2 rounded-full bg-accent px-4 py-2 text-xs font-bold text-white transition-all duration-200 hover:bg-accent-deep hover:scale-105"
                >
                  <Award className="h-4 w-4" /> Получить сертификат
                </Link>
              ) : (
                <p className="mt-4 text-xs text-fog">Сертификат откроется после 100% уроков курса.</p>
              )}
            </div>
          );
        })}
      </div>

      <h2 className="mt-14 font-display text-2xl font-extrabold text-paper">История викторин</h2>
      {state.attempts.length === 0 ? (
        <p className="mt-4 rounded-2xl border border-line bg-coal p-6 text-sm text-fog">
          Попыток пока нет. Пройдите викторину любого урока — результат появится здесь.
        </p>
      ) : (
        <div className="mt-5 overflow-x-auto rounded-2xl border border-line bg-coal">
          <table className="w-full min-w-[640px] text-left text-sm">
            <thead>
              <tr className="border-b border-line text-xs uppercase tracking-wider text-fog">
                <th className="px-5 py-3 font-bold">Дата</th>
                <th className="px-5 py-3 font-bold">Курс</th>
                <th className="px-5 py-3 font-bold">Урок</th>
                <th className="px-5 py-3 font-bold">Результат</th>
                <th className="px-5 py-3 font-bold">Статус</th>
              </tr>
            </thead>
            <tbody>
              {state.attempts.slice(0, 20).map((attempt) => (
                <tr key={attempt.id} className="border-b border-line/50 text-silver">
                  <td className="px-5 py-3 whitespace-nowrap">{new Date(attempt.date).toLocaleString('ru-RU', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' })}</td>
                  <td className="px-5 py-3">{attempt.courseTitle}</td>
                  <td className="px-5 py-3">{attempt.lessonTitle}</td>
                  <td className="px-5 py-3 font-bold text-paper">{attempt.percent}%</td>
                  <td className="px-5 py-3">
                    <span className={`rounded-full px-3 py-1 text-xs font-bold ${attempt.passed ? 'bg-ok/15 text-ok' : 'bg-bad/15 text-bad'}`}>
                      {attempt.passed ? 'Зачёт' : 'Пересдача'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
