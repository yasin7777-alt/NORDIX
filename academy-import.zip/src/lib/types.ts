export type CycleNodeId = 'compressor' | 'condenser' | 'expansion' | 'evaporator';

export interface TermEntry {
  term: string;
  def: string;
}

export interface TheorySection {
  heading: string;
  text: string;
}

export interface TheoryBlock {
  intro: string;
  sections: TheorySection[];
  keyPoints: string[];
}

export interface Illustration {
  src: string;
  alt: string;
  caption: string;
}

export interface VideoMaterial {
  src: string;
  caption: string;
  note: string;
}

export type PracticeTask =
  | {
      kind: 'match';
      title: string;
      prompt: string;
      pairs: { left: string; right: string }[];
    }
  | {
      kind: 'order';
      title: string;
      prompt: string;
      steps: string[];
    }
  | {
      kind: 'choice';
      title: string;
      prompt: string;
      options: string[];
      correct: number;
      explanation: string;
    }
  | {
      kind: 'cycle-click';
      title: string;
      prompt: string;
      questions: { prompt: string; nodeId: CycleNodeId }[];
    };

export interface QuizQuestion {
  q: string;
  options: string[];
  correct: number;
  explain: string;
}

export interface Lesson {
  id: string;
  num: number;
  title: string;
  theory: TheoryBlock;
  terms: TermEntry[];
  illustration: Illustration;
  video: VideoMaterial;
  practice: PracticeTask;
  quiz: QuizQuestion[];
}

export interface CourseMeta {
  id: string;
  num: number;
  title: string;
  tagline: string;
  description: string;
  status: 'ready' | 'soon';
  lessonTitles: string[];
  image: string;
}

export type StageId = 'theory' | 'video' | 'practice' | 'quiz' | 'result';
