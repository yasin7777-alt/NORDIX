import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import type { ReactNode } from 'react';
import {
  addAttempt,
  emptyState,
  issueCertificate,
  loadState,
  markLessonCompleted,
  passSafety,
  serializeState,
  setStudentName,
  STORAGE_KEY,
} from './progress';
import type { ProgressState, QuizAttempt } from './progress';

interface ProgressContextValue {
  state: ProgressState;
  completeLesson: (courseId: string, lessonId: string) => void;
  recordAttempt: (attempt: Omit<QuizAttempt, 'id' | 'date'>) => QuizAttempt;
  markSafetyPassed: () => void;
  saveStudentName: (name: string) => void;
  grantCertificate: (courseId: string) => string;
  resetProgress: () => void;
}

const ProgressContext = createContext<ProgressContextValue | null>(null);

function readStorage(): string | null {
  try {
    return window.localStorage.getItem(STORAGE_KEY);
  } catch {
    return null;
  }
}

function writeStorage(value: string): void {
  try {
    window.localStorage.setItem(STORAGE_KEY, value);
  } catch {
    /* storage unavailable — progress lives in memory only */
  }
}

export function ProgressProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<ProgressState>(() => loadState(readStorage));

  useEffect(() => {
    writeStorage(serializeState(state));
  }, [state]);

  const completeLesson = useCallback((courseId: string, lessonId: string) => {
    setState((prev) => markLessonCompleted(prev, courseId, lessonId));
  }, []);

  const recordAttempt = useCallback((attempt: Omit<QuizAttempt, 'id' | 'date'>): QuizAttempt => {
    const full: QuizAttempt = {
      ...attempt,
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      date: new Date().toISOString(),
    };
    setState((prev) => addAttempt(prev, full));
    return full;
  }, []);

  const markSafetyPassed = useCallback(() => {
    setState((prev) => passSafety(prev));
  }, []);

  const saveStudentName = useCallback((name: string) => {
    setState((prev) => setStudentName(prev, name));
  }, []);

  const grantCertificate = useCallback((courseId: string): string => {
    const date = new Date().toISOString();
    setState((prev) => (prev.certificates[courseId] ? prev : issueCertificate(prev, courseId, date)));
    return date;
  }, []);

  const resetProgress = useCallback(() => {
    setState(emptyState());
  }, []);

  const value = useMemo(
    () => ({ state, completeLesson, recordAttempt, markSafetyPassed, saveStudentName, grantCertificate, resetProgress }),
    [state, completeLesson, recordAttempt, markSafetyPassed, saveStudentName, grantCertificate, resetProgress],
  );

  return <ProgressContext.Provider value={value}>{children}</ProgressContext.Provider>;
}

export function useProgress(): ProgressContextValue {
  const ctx = useContext(ProgressContext);
  if (!ctx) throw new Error('useProgress must be used inside ProgressProvider');
  return ctx;
}
