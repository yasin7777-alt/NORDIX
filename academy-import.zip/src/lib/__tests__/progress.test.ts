import { describe, expect, it } from 'vitest';
import {
  addAttempt,
  coursePercent,
  emptyState,
  isCourseComplete,
  issueCertificate,
  loadState,
  markLessonCompleted,
  serializeState,
  STORAGE_KEY,
} from '../progress';
import type { QuizAttempt } from '../progress';

function memoryStorage(initial: string | null = null) {
  let value = initial;
  return {
    read: () => value,
    write: (next: string) => {
      value = next;
    },
  };
}

const attempt = (over: Partial<QuizAttempt> = {}): QuizAttempt => ({
  id: 'a1',
  courseId: 'course-1',
  courseTitle: 'База холодильной техники',
  lessonId: 'c1-l1',
  lessonTitle: 'Термины',
  correct: 3,
  total: 4,
  percent: 75,
  passed: true,
  date: '2026-01-01T10:00:00.000Z',
  ...over,
});

describe('loadState', () => {
  it('returns empty state when storage is empty', () => {
    const storage = memoryStorage();
    expect(loadState(storage.read)).toEqual(emptyState());
  });

  it('restores saved state', () => {
    const storage = memoryStorage();
    const state = markLessonCompleted(emptyState(), 'course-1', 'c1-l1');
    storage.write(serializeState(state));
    expect(loadState(storage.read).completed['course-1']).toEqual(['c1-l1']);
  });

  it('survives corrupted storage', () => {
    const storage = memoryStorage('{not json');
    expect(loadState(storage.read)).toEqual(emptyState());
  });

  it('uses the documented storage key', () => {
    expect(STORAGE_KEY).toBe('nordix-progress-v1');
  });
});

describe('lesson completion and percents', () => {
  it('marks a lesson completed once', () => {
    let state = markLessonCompleted(emptyState(), 'course-1', 'c1-l1');
    state = markLessonCompleted(state, 'course-1', 'c1-l1');
    expect(state.completed['course-1']).toEqual(['c1-l1']);
  });

  it('computes course percent', () => {
    let state = emptyState();
    state = markLessonCompleted(state, 'course-1', 'c1-l1');
    state = markLessonCompleted(state, 'course-1', 'c1-l2');
    expect(coursePercent(state, 'course-1', 10)).toBe(20);
    expect(isCourseComplete(state, 'course-1', 10)).toBe(false);
  });

  it('detects full completion', () => {
    let state = emptyState();
    for (let i = 1; i <= 10; i++) state = markLessonCompleted(state, 'course-1', `c1-l${i}`);
    expect(coursePercent(state, 'course-1', 10)).toBe(100);
    expect(isCourseComplete(state, 'course-1', 10)).toBe(true);
  });
});

describe('attempts and certificates', () => {
  it('stores newest attempt first', () => {
    let state = addAttempt(emptyState(), attempt());
    state = addAttempt(state, attempt({ id: 'a2', percent: 50 }));
    expect(state.attempts[0].id).toBe('a2');
    expect(state.attempts).toHaveLength(2);
  });

  it('issues a certificate date once', () => {
    const state = issueCertificate(emptyState(), 'course-1', '2026-05-01T00:00:00.000Z');
    expect(state.certificates['course-1']).toBe('2026-05-01T00:00:00.000Z');
  });
});
