import { describe, expect, it } from 'vitest';
import { COURSES, getCourse, getCourseLessons, getLesson } from '../content/courses';
import { course1Lessons } from '../content/course1';

const EXPECTED_LESSON_COUNTS: Record<string, number> = {
  'course-1': 10,
  'course-2': 10,
  'course-3': 9,
  'course-4': 8,
  'course-5': 9,
  'course-6': 7,
};

const ALLOWED_MEDIA = [
  'videos/hero-loop.mp4',
  'videos/frost-loop.mp4',
  'videos/compressor-loop.mp4',
  'images/hero-cold.jpg',
  'images/compressor.jpg',
  'images/condenser.jpg',
  'images/evaporator.png',
  'images/electric-panel.png',
  'images/tools-gauges.png',
];

describe('catalog', () => {
  it('contains only the imported course', () => {
    expect(COURSES).toHaveLength(1);
    expect(COURSES.map((c) => c.num)).toEqual([1]);
  });

  it('declares the planned lesson counts', () => {
    for (const course of COURSES) {
      expect(course.lessonTitles).toHaveLength(EXPECTED_LESSON_COUNTS[course.id]);
    }
  });

  it('has exactly one fully ready course at stage one', () => {
    expect(COURSES.filter((c) => c.status === 'ready').map((c) => c.id)).toEqual(['course-1']);
  });
});

describe('course 1 content integrity', () => {
  it('has ten numbered lessons in order', () => {
    expect(course1Lessons).toHaveLength(10);
    course1Lessons.forEach((lesson, i) => {
      expect(lesson.num).toBe(i + 1);
      expect(lesson.id).toBe(`c1-l${i + 1}`);
    });
  });

  it('matches catalog titles', () => {
    const course = getCourse('course-1');
    expect(course?.lessonTitles).toEqual(course1Lessons.map((l) => l.title));
  });

  it('every lesson has theory, terms, media, practice and quiz', () => {
    for (const lesson of course1Lessons) {
      expect(lesson.theory.sections.length).toBeGreaterThanOrEqual(2);
      expect(lesson.theory.keyPoints.length).toBeGreaterThanOrEqual(3);
      expect(lesson.terms.length).toBeGreaterThanOrEqual(3);
      expect(lesson.quiz.length).toBeGreaterThanOrEqual(3);
      expect(ALLOWED_MEDIA).toContain(lesson.video.src);
      expect(ALLOWED_MEDIA).toContain(lesson.illustration.src);
      expect(lesson.practice).toBeTruthy();
    }
  });

  it('quiz correct indexes are valid', () => {
    for (const lesson of course1Lessons) {
      for (const question of lesson.quiz) {
        expect(question.options.length).toBeGreaterThanOrEqual(2);
        expect(question.correct).toBeGreaterThanOrEqual(0);
        expect(question.correct).toBeLessThan(question.options.length);
        expect(question.explain.length).toBeGreaterThan(10);
      }
    }
  });

  it('practice tasks are self-consistent', () => {
    for (const lesson of course1Lessons) {
      const task = lesson.practice;
      if (task.kind === 'match') expect(task.pairs.length).toBeGreaterThanOrEqual(3);
      if (task.kind === 'order') expect(task.steps.length).toBeGreaterThanOrEqual(4);
      if (task.kind === 'choice') expect(task.correct).toBeLessThan(task.options.length);
      if (task.kind === 'cycle-click') expect(task.questions.length).toBeGreaterThanOrEqual(3);
    }
  });
});

describe('lookups', () => {
  it('resolves lessons of the ready course', () => {
    expect(getCourseLessons('course-1')).toHaveLength(10);
    expect(getLesson('course-1', 'c1-l4')?.title).toBe('Компрессор');
  });

  it('returns empty lessons for upcoming courses', () => {
    expect(getCourseLessons('course-2')).toEqual([]);
    expect(getLesson('course-2', 'x')).toBeUndefined();
  });
});
