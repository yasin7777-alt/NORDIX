import { describe, expect, it } from 'vitest';
import { buildRecommendations, PASS_PERCENT, scoreQuiz } from '../quiz';
import type { QuizQuestion } from '../types';

const QUESTIONS: QuizQuestion[] = [
  { q: 'Q1', options: ['a', 'b'], correct: 1, explain: 'e1' },
  { q: 'Q2', options: ['a', 'b', 'c'], correct: 0, explain: 'e2' },
  { q: 'Q3', options: ['a', 'b'], correct: 0, explain: 'e3' },
  { q: 'Q4', options: ['a', 'b'], correct: 1, explain: 'e4' },
];

describe('scoreQuiz', () => {
  it('scores a perfect attempt as 100% and passed', () => {
    const result = scoreQuiz(QUESTIONS, [1, 0, 0, 1]);
    expect(result.correct).toBe(4);
    expect(result.percent).toBe(100);
    expect(result.passed).toBe(true);
    expect(result.perQuestion).toEqual([true, true, true, true]);
  });

  it('fails below the 70% threshold', () => {
    const result = scoreQuiz(QUESTIONS, [1, 0, 1, 0]);
    expect(result.percent).toBe(50);
    expect(result.passed).toBe(false);
  });

  it('passes at the 70% boundary (3 of 4)', () => {
    const result = scoreQuiz(QUESTIONS, [1, 0, 0, 0]);
    expect(result.percent).toBe(75);
    expect(result.passed).toBe(true);
    expect(PASS_PERCENT).toBe(70);
  });

  it('marks unanswered questions as wrong', () => {
    const result = scoreQuiz(QUESTIONS, [1, null, null, null]);
    expect(result.correct).toBe(1);
    expect(result.percent).toBe(25);
  });
});

describe('buildRecommendations', () => {
  it('adds a retry recommendation when the quiz is failed', () => {
    const result = scoreQuiz(QUESTIONS, [1, 1, 1, 0]);
    const recs = buildRecommendations(QUESTIONS, result, 'Компрессор');
    expect(recs.some((r) => r.includes('Компрессор'))).toBe(true);
    expect(recs.some((r) => r.includes('вопрос №2'))).toBe(true);
  });

  it('confirms mastery when the quiz is passed', () => {
    const result = scoreQuiz(QUESTIONS, [1, 0, 0, 1]);
    const recs = buildRecommendations(QUESTIONS, result, 'Компрессор');
    expect(recs.some((r) => r.includes('усвоена'))).toBe(true);
  });
});
