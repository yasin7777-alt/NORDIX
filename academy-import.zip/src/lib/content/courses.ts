import type { CourseMeta, Lesson } from '../types';
import { course1Lessons } from './course1';

export const COURSES: CourseMeta[] = [
  {
    id: 'course-1',
    num: 1,
    title: 'База холодильной техники',
    tagline: 'От полного новичка до понимания принципов охлаждения',
    description:
      'Фундамент профессии: термины, устройство контура, компрессор, конденсатор, испаритель, хладагенты, ТРВ и полный холодильный цикл с итоговой проверкой.',
    status: 'ready',
    lessonTitles: course1Lessons.map((l) => l.title),
    image: 'images/hero-cold.jpg',
  },
];

export function getCourse(courseId: string): CourseMeta | undefined {
  return COURSES.find((c) => c.id === courseId);
}

export function getCourseLessons(courseId: string): Lesson[] {
  if (courseId === 'course-1') return course1Lessons;
  return [];
}

export function getLesson(courseId: string, lessonId: string): Lesson | undefined {
  return getCourseLessons(courseId).find((l) => l.id === lessonId);
}
