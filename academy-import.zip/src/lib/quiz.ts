import type { QuizQuestion } from './types';

export const PASS_PERCENT = 70;

export interface QuizResult {
  correct: number;
  total: number;
  percent: number;
  passed: boolean;
  perQuestion: boolean[];
}

export function scoreQuiz(
  questions: QuizQuestion[],
  answers: (number | null)[],
): QuizResult {
  const perQuestion = questions.map((question, index) => answers[index] === question.correct);
  const correct = perQuestion.filter(Boolean).length;
  const total = questions.length;
  const percent = total === 0 ? 0 : Math.round((correct / total) * 100);
  return { correct, total, percent, passed: percent >= PASS_PERCENT, perQuestion };
}

export function buildRecommendations(
  questions: QuizQuestion[],
  result: QuizResult,
  lessonTitle: string,
): string[] {
  const recommendations: string[] = [];
  result.perQuestion.forEach((ok, index) => {
    if (!ok) recommendations.push(`Повторите вопрос №${index + 1}: «${questions[index].q}» — разбор дан в объяснении.`);
  });
  if (result.passed) {
    recommendations.push(`Тема «${lessonTitle}» усвоена. Можно двигаться к следующему уроку.`);
  } else {
    recommendations.push(`Вернитесь к этапам «Теория» и «Видео» урока «${lessonTitle}» и пройдите викторину ещё раз.`);
  }
  return recommendations;
}
