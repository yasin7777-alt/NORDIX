export const STORAGE_KEY = 'nordix-progress-v1';

export interface QuizAttempt {
  id: string;
  courseId: string;
  courseTitle: string;
  lessonId: string;
  lessonTitle: string;
  correct: number;
  total: number;
  percent: number;
  passed: boolean;
  date: string;
}

export interface ProgressState {
  completed: Record<string, string[]>;
  attempts: QuizAttempt[];
  safetyPassed: boolean;
  studentName: string;
  certificates: Record<string, string>;
}

export function emptyState(): ProgressState {
  return { completed: {}, attempts: [], safetyPassed: false, studentName: '', certificates: {} };
}

export function loadState(read: () => string | null): ProgressState {
  try {
    const raw = read();
    if (!raw) return emptyState();
    const parsed = JSON.parse(raw) as Partial<ProgressState>;
    return {
      completed: parsed.completed ?? {},
      attempts: Array.isArray(parsed.attempts) ? parsed.attempts : [],
      safetyPassed: Boolean(parsed.safetyPassed),
      studentName: typeof parsed.studentName === 'string' ? parsed.studentName : '',
      certificates: parsed.certificates ?? {},
    };
  } catch {
    return emptyState();
  }
}

export function serializeState(state: ProgressState): string {
  return JSON.stringify(state);
}

export function markLessonCompleted(state: ProgressState, courseId: string, lessonId: string): ProgressState {
  const current = state.completed[courseId] ?? [];
  if (current.includes(lessonId)) return state;
  return {
    ...state,
    completed: { ...state.completed, [courseId]: [...current, lessonId] },
  };
}

export function completedCount(state: ProgressState, courseId: string): number {
  return (state.completed[courseId] ?? []).length;
}

export function coursePercent(state: ProgressState, courseId: string, totalLessons: number): number {
  if (totalLessons <= 0) return 0;
  return Math.round((completedCount(state, courseId) / totalLessons) * 100);
}

export function isCourseComplete(state: ProgressState, courseId: string, totalLessons: number): boolean {
  return totalLessons > 0 && completedCount(state, courseId) >= totalLessons;
}

export function bestAttempt(state: ProgressState, courseId: string, lessonId: string): QuizAttempt | null {
  const list = state.attempts.filter((a) => a.courseId === courseId && a.lessonId === lessonId);
  if (list.length === 0) return null;
  return list.reduce((best, a) => (a.percent > best.percent ? a : best), list[0]);
}

export function addAttempt(state: ProgressState, attempt: QuizAttempt): ProgressState {
  return { ...state, attempts: [attempt, ...state.attempts].slice(0, 200) };
}

export function passSafety(state: ProgressState): ProgressState {
  return { ...state, safetyPassed: true };
}

export function setStudentName(state: ProgressState, name: string): ProgressState {
  return { ...state, studentName: name };
}

export function issueCertificate(state: ProgressState, courseId: string, date: string): ProgressState {
  return { ...state, certificates: { ...state.certificates, [courseId]: date } };
}
